﻿namespace Food_Program
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.buttonMcdonals = new System.Windows.Forms.Button();
            this.textWelcome = new System.Windows.Forms.Label();
            this.CostumersNameTxt = new System.Windows.Forms.Label();
            this.CostumersAddressTxt = new System.Windows.Forms.Label();
            this.CostumersPhoneTxt = new System.Windows.Forms.Label();
            this.Wendysbutton = new System.Windows.Forms.Button();
            this.CostumersNametextBox = new System.Windows.Forms.TextBox();
            this.CostumersAddresstextBox = new System.Windows.Forms.TextBox();
            this.CostumersPhonetextBox = new System.Windows.Forms.TextBox();
            this.buttonInNOut = new System.Windows.Forms.Button();
            this.checkBoxPickup = new System.Windows.Forms.CheckBox();
            this.checkBoxDelivery = new System.Windows.Forms.CheckBox();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonMcdonals
            // 
            this.buttonMcdonals.Location = new System.Drawing.Point(37, 192);
            this.buttonMcdonals.Name = "buttonMcdonals";
            this.buttonMcdonals.Size = new System.Drawing.Size(75, 23);
            this.buttonMcdonals.TabIndex = 0;
            this.buttonMcdonals.Text = "Mcdonals ";
            this.buttonMcdonals.UseVisualStyleBackColor = true;
            this.buttonMcdonals.Click += new System.EventHandler(this.buttonMcdonals_Click);
            // 
            // textWelcome
            // 
            this.textWelcome.AutoSize = true;
            this.textWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.textWelcome.Location = new System.Drawing.Point(97, 9);
            this.textWelcome.Name = "textWelcome";
            this.textWelcome.Size = new System.Drawing.Size(257, 20);
            this.textWelcome.TabIndex = 1;
            this.textWelcome.Text = "Welcome To Aldo\'s Food Service";
            this.textWelcome.Click += new System.EventHandler(this.label1_Click);
            // 
            // CostumersNameTxt
            // 
            this.CostumersNameTxt.AutoSize = true;
            this.CostumersNameTxt.Location = new System.Drawing.Point(34, 62);
            this.CostumersNameTxt.Name = "CostumersNameTxt";
            this.CostumersNameTxt.Size = new System.Drawing.Size(90, 13);
            this.CostumersNameTxt.TabIndex = 2;
            this.CostumersNameTxt.Text = "Costumers Name:";
            this.CostumersNameTxt.Click += new System.EventHandler(this.CostumersNameTxt_Click);
            // 
            // CostumersAddressTxt
            // 
            this.CostumersAddressTxt.AutoSize = true;
            this.CostumersAddressTxt.Location = new System.Drawing.Point(34, 89);
            this.CostumersAddressTxt.Name = "CostumersAddressTxt";
            this.CostumersAddressTxt.Size = new System.Drawing.Size(100, 13);
            this.CostumersAddressTxt.TabIndex = 3;
            this.CostumersAddressTxt.Text = "Costumers Address:";
            this.CostumersAddressTxt.Click += new System.EventHandler(this.CostumersAddressTxt_Click);
            // 
            // CostumersPhoneTxt
            // 
            this.CostumersPhoneTxt.AutoSize = true;
            this.CostumersPhoneTxt.Location = new System.Drawing.Point(34, 115);
            this.CostumersPhoneTxt.Name = "CostumersPhoneTxt";
            this.CostumersPhoneTxt.Size = new System.Drawing.Size(103, 13);
            this.CostumersPhoneTxt.TabIndex = 4;
            this.CostumersPhoneTxt.Text = "Costumers Phone #:";
            this.CostumersPhoneTxt.Click += new System.EventHandler(this.CostumersPhoneTxt_Click);
            // 
            // Wendysbutton
            // 
            this.Wendysbutton.Location = new System.Drawing.Point(132, 192);
            this.Wendysbutton.Name = "Wendysbutton";
            this.Wendysbutton.Size = new System.Drawing.Size(75, 23);
            this.Wendysbutton.TabIndex = 8;
            this.Wendysbutton.Text = "Wendy\'s";
            this.Wendysbutton.UseVisualStyleBackColor = true;
            this.Wendysbutton.Click += new System.EventHandler(this.button2_Click);
            // 
            // CostumersNametextBox
            // 
            this.CostumersNametextBox.Location = new System.Drawing.Point(251, 55);
            this.CostumersNametextBox.Name = "CostumersNametextBox";
            this.CostumersNametextBox.Size = new System.Drawing.Size(132, 20);
            this.CostumersNametextBox.TabIndex = 9;
            this.CostumersNametextBox.TextChanged += new System.EventHandler(this.CostumersNametextBox_TextChanged);
            // 
            // CostumersAddresstextBox
            // 
            this.CostumersAddresstextBox.Location = new System.Drawing.Point(251, 81);
            this.CostumersAddresstextBox.Name = "CostumersAddresstextBox";
            this.CostumersAddresstextBox.Size = new System.Drawing.Size(132, 20);
            this.CostumersAddresstextBox.TabIndex = 10;
            this.CostumersAddresstextBox.TextChanged += new System.EventHandler(this.CostumersAddresstextBox_TextChanged);
            // 
            // CostumersPhonetextBox
            // 
            this.CostumersPhonetextBox.Location = new System.Drawing.Point(251, 108);
            this.CostumersPhonetextBox.Name = "CostumersPhonetextBox";
            this.CostumersPhonetextBox.Size = new System.Drawing.Size(132, 20);
            this.CostumersPhonetextBox.TabIndex = 11;
            this.CostumersPhonetextBox.TextChanged += new System.EventHandler(this.txtCostumersPhone_TextChanged);
            // 
            // buttonInNOut
            // 
            this.buttonInNOut.Location = new System.Drawing.Point(234, 192);
            this.buttonInNOut.Name = "buttonInNOut";
            this.buttonInNOut.Size = new System.Drawing.Size(120, 23);
            this.buttonInNOut.TabIndex = 12;
            this.buttonInNOut.Text = "In-N-Out Burger";
            this.buttonInNOut.UseVisualStyleBackColor = true;
            this.buttonInNOut.Click += new System.EventHandler(this.buttonInNOut_Click);
            // 
            // checkBoxPickup
            // 
            this.checkBoxPickup.AutoSize = true;
            this.checkBoxPickup.Location = new System.Drawing.Point(37, 147);
            this.checkBoxPickup.Name = "checkBoxPickup";
            this.checkBoxPickup.Size = new System.Drawing.Size(62, 17);
            this.checkBoxPickup.TabIndex = 13;
            this.checkBoxPickup.Text = "Pick-up";
            this.checkBoxPickup.UseVisualStyleBackColor = true;
            this.checkBoxPickup.CheckedChanged += new System.EventHandler(this.checkBoxPickup_CheckedChanged);
            // 
            // checkBoxDelivery
            // 
            this.checkBoxDelivery.AutoSize = true;
            this.checkBoxDelivery.Location = new System.Drawing.Point(269, 147);
            this.checkBoxDelivery.Name = "checkBoxDelivery";
            this.checkBoxDelivery.Size = new System.Drawing.Size(100, 17);
            this.checkBoxDelivery.TabIndex = 14;
            this.checkBoxDelivery.Text = "Delivery ($5.00)";
            this.checkBoxDelivery.UseVisualStyleBackColor = true;
            this.checkBoxDelivery.CheckedChanged += new System.EventHandler(this.checkBoxDelivery_CheckedChanged);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(382, 192);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 23);
            this.Exitbutton.TabIndex = 15;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(478, 240);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.checkBoxDelivery);
            this.Controls.Add(this.checkBoxPickup);
            this.Controls.Add(this.buttonInNOut);
            this.Controls.Add(this.CostumersPhonetextBox);
            this.Controls.Add(this.CostumersAddresstextBox);
            this.Controls.Add(this.CostumersNametextBox);
            this.Controls.Add(this.Wendysbutton);
            this.Controls.Add(this.CostumersPhoneTxt);
            this.Controls.Add(this.CostumersAddressTxt);
            this.Controls.Add(this.CostumersNameTxt);
            this.Controls.Add(this.textWelcome);
            this.Controls.Add(this.buttonMcdonals);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonMcdonals;
        private System.Windows.Forms.Label textWelcome;
        private System.Windows.Forms.Label CostumersNameTxt;
        private System.Windows.Forms.Label CostumersAddressTxt;
        private System.Windows.Forms.Label CostumersPhoneTxt;
        private System.Windows.Forms.Button Wendysbutton;
        private System.Windows.Forms.TextBox CostumersNametextBox;
        private System.Windows.Forms.TextBox CostumersAddresstextBox;
        private System.Windows.Forms.TextBox CostumersPhonetextBox;
        private System.Windows.Forms.Button buttonInNOut;
        private System.Windows.Forms.CheckBox checkBoxPickup;
        private System.Windows.Forms.CheckBox checkBoxDelivery;
        private System.Windows.Forms.Button Exitbutton;
    }
}

