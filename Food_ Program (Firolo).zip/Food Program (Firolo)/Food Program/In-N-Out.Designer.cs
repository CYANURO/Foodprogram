﻿namespace Food_Program
{
    partial class In_N_Out
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(In_N_Out));
            this.InNOut = new System.Windows.Forms.Label();
            this.iCostumersName = new System.Windows.Forms.Label();
            this.iCostumersPhone = new System.Windows.Forms.Label();
            this.iCostumersNametextBox = new System.Windows.Forms.TextBox();
            this.iCostumersPhonetextBox = new System.Windows.Forms.TextBox();
            this.InNOutAddress = new System.Windows.Forms.Label();
            this.InNOutPhone = new System.Windows.Forms.Label();
            this.wHamburgersTxt = new System.Windows.Forms.Label();
            this.iDoubleDoubleTxt = new System.Windows.Forms.Label();
            this.iChesseburgerTxt = new System.Windows.Forms.Label();
            this.iHamburgerTxt = new System.Windows.Forms.Label();
            this.iDoubleDoublenumeric = new System.Windows.Forms.NumericUpDown();
            this.iCheeseburgernumeric = new System.Windows.Forms.NumericUpDown();
            this.iHamburgernumeric = new System.Windows.Forms.NumericUpDown();
            this.NotSoSecretTxt = new System.Windows.Forms.Label();
            this.iDoubleMeatTxt = new System.Windows.Forms.Label();
            this.i4x4Txt = new System.Windows.Forms.Label();
            this.i3x3Txt = new System.Windows.Forms.Label();
            this.iAnimalTxt = new System.Windows.Forms.Label();
            this.iDoubleMeatnumeric = new System.Windows.Forms.NumericUpDown();
            this.i4x4numeric = new System.Windows.Forms.NumericUpDown();
            this.i3x3numeric = new System.Windows.Forms.NumericUpDown();
            this.iAnimalnumeric = new System.Windows.Forms.NumericUpDown();
            this.iSidesTxt = new System.Windows.Forms.Label();
            this.isSoftDrinkTxt = new System.Windows.Forms.Label();
            this.imSoftDrinkTxt = new System.Windows.Forms.Label();
            this.ilSoftDrinkTxt = new System.Windows.Forms.Label();
            this.iShakesTxt = new System.Windows.Forms.Label();
            this.iFriesTxt = new System.Windows.Forms.Label();
            this.iChiliCheeseTxt = new System.Windows.Forms.Label();
            this.isSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.imSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.ilSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.iShakenumeric = new System.Windows.Forms.NumericUpDown();
            this.iFriesnumeric = new System.Windows.Forms.NumericUpDown();
            this.iChiliCheesenumeric = new System.Windows.Forms.NumericUpDown();
            this.iCalculate = new System.Windows.Forms.Button();
            this.iTaxTxt = new System.Windows.Forms.Label();
            this.iTotalTxt = new System.Windows.Forms.Label();
            this.iOrderbutton = new System.Windows.Forms.Button();
            this.iExitbutton = new System.Windows.Forms.Button();
            this.iCalculatetextBox = new System.Windows.Forms.TextBox();
            this.iTaxtextBox = new System.Windows.Forms.TextBox();
            this.iTotaltextBox = new System.Windows.Forms.TextBox();
            this.iCostumersAddresstextBox = new System.Windows.Forms.TextBox();
            this.iCostumersAddressTxt = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.iDoubleDoublenumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iCheeseburgernumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iHamburgernumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iDoubleMeatnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.i4x4numeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.i3x3numeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iAnimalnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.isSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ilSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iShakenumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iFriesnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iChiliCheesenumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // InNOut
            // 
            this.InNOut.AutoSize = true;
            this.InNOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InNOut.Location = new System.Drawing.Point(269, 9);
            this.InNOut.Name = "InNOut";
            this.InNOut.Size = new System.Drawing.Size(89, 24);
            this.InNOut.TabIndex = 0;
            this.InNOut.Text = "In-N-Out";
            // 
            // iCostumersName
            // 
            this.iCostumersName.AutoSize = true;
            this.iCostumersName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iCostumersName.Location = new System.Drawing.Point(12, 79);
            this.iCostumersName.Name = "iCostumersName";
            this.iCostumersName.Size = new System.Drawing.Size(106, 15);
            this.iCostumersName.TabIndex = 1;
            this.iCostumersName.Text = "Costumers Name:";
            // 
            // iCostumersPhone
            // 
            this.iCostumersPhone.AutoSize = true;
            this.iCostumersPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iCostumersPhone.Location = new System.Drawing.Point(12, 109);
            this.iCostumersPhone.Name = "iCostumersPhone";
            this.iCostumersPhone.Size = new System.Drawing.Size(118, 15);
            this.iCostumersPhone.TabIndex = 2;
            this.iCostumersPhone.Text = "Costumers Phone #:";
            // 
            // iCostumersNametextBox
            // 
            this.iCostumersNametextBox.Location = new System.Drawing.Point(149, 79);
            this.iCostumersNametextBox.Name = "iCostumersNametextBox";
            this.iCostumersNametextBox.ReadOnly = true;
            this.iCostumersNametextBox.Size = new System.Drawing.Size(100, 20);
            this.iCostumersNametextBox.TabIndex = 3;
            // 
            // iCostumersPhonetextBox
            // 
            this.iCostumersPhonetextBox.Location = new System.Drawing.Point(149, 109);
            this.iCostumersPhonetextBox.Name = "iCostumersPhonetextBox";
            this.iCostumersPhonetextBox.ReadOnly = true;
            this.iCostumersPhonetextBox.Size = new System.Drawing.Size(100, 20);
            this.iCostumersPhonetextBox.TabIndex = 4;
            // 
            // InNOutAddress
            // 
            this.InNOutAddress.AutoSize = true;
            this.InNOutAddress.Location = new System.Drawing.Point(191, 33);
            this.InNOutAddress.Name = "InNOutAddress";
            this.InNOutAddress.Size = new System.Drawing.Size(249, 13);
            this.InNOutAddress.TabIndex = 5;
            this.InNOutAddress.Text = "3715 Constitution Blvd, West Valley City, UT 84119";
            // 
            // InNOutPhone
            // 
            this.InNOutPhone.AutoSize = true;
            this.InNOutPhone.Location = new System.Drawing.Point(270, 46);
            this.InNOutPhone.Name = "InNOutPhone";
            this.InNOutPhone.Size = new System.Drawing.Size(79, 13);
            this.InNOutPhone.TabIndex = 6;
            this.InNOutPhone.Text = "(801) 786-1000";
            // 
            // wHamburgersTxt
            // 
            this.wHamburgersTxt.AutoSize = true;
            this.wHamburgersTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wHamburgersTxt.Location = new System.Drawing.Point(12, 172);
            this.wHamburgersTxt.Name = "wHamburgersTxt";
            this.wHamburgersTxt.Size = new System.Drawing.Size(93, 16);
            this.wHamburgersTxt.TabIndex = 7;
            this.wHamburgersTxt.Text = "Hamburgers";
            // 
            // iDoubleDoubleTxt
            // 
            this.iDoubleDoubleTxt.AutoSize = true;
            this.iDoubleDoubleTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iDoubleDoubleTxt.Location = new System.Drawing.Point(57, 203);
            this.iDoubleDoubleTxt.Name = "iDoubleDoubleTxt";
            this.iDoubleDoubleTxt.Size = new System.Drawing.Size(133, 15);
            this.iDoubleDoubleTxt.TabIndex = 8;
            this.iDoubleDoubleTxt.Text = "Double-Double ($3.99)";
            // 
            // iChesseburgerTxt
            // 
            this.iChesseburgerTxt.AutoSize = true;
            this.iChesseburgerTxt.Location = new System.Drawing.Point(57, 231);
            this.iChesseburgerTxt.Name = "iChesseburgerTxt";
            this.iChesseburgerTxt.Size = new System.Drawing.Size(109, 13);
            this.iChesseburgerTxt.TabIndex = 9;
            this.iChesseburgerTxt.Text = "Cheeseburger ($2.99)";
            // 
            // iHamburgerTxt
            // 
            this.iHamburgerTxt.AutoSize = true;
            this.iHamburgerTxt.Location = new System.Drawing.Point(57, 257);
            this.iHamburgerTxt.Name = "iHamburgerTxt";
            this.iHamburgerTxt.Size = new System.Drawing.Size(95, 13);
            this.iHamburgerTxt.TabIndex = 10;
            this.iHamburgerTxt.Text = "Hamburger ($2.50)";
            // 
            // iDoubleDoublenumeric
            // 
            this.iDoubleDoublenumeric.Location = new System.Drawing.Point(15, 198);
            this.iDoubleDoublenumeric.Name = "iDoubleDoublenumeric";
            this.iDoubleDoublenumeric.Size = new System.Drawing.Size(36, 20);
            this.iDoubleDoublenumeric.TabIndex = 11;
            // 
            // iCheeseburgernumeric
            // 
            this.iCheeseburgernumeric.Location = new System.Drawing.Point(15, 224);
            this.iCheeseburgernumeric.Name = "iCheeseburgernumeric";
            this.iCheeseburgernumeric.Size = new System.Drawing.Size(36, 20);
            this.iCheeseburgernumeric.TabIndex = 12;
            // 
            // iHamburgernumeric
            // 
            this.iHamburgernumeric.Location = new System.Drawing.Point(15, 250);
            this.iHamburgernumeric.Name = "iHamburgernumeric";
            this.iHamburgernumeric.Size = new System.Drawing.Size(36, 20);
            this.iHamburgernumeric.TabIndex = 13;
            // 
            // NotSoSecretTxt
            // 
            this.NotSoSecretTxt.AutoSize = true;
            this.NotSoSecretTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NotSoSecretTxt.Location = new System.Drawing.Point(16, 327);
            this.NotSoSecretTxt.Name = "NotSoSecretTxt";
            this.NotSoSecretTxt.Size = new System.Drawing.Size(147, 16);
            this.NotSoSecretTxt.TabIndex = 14;
            this.NotSoSecretTxt.Text = "Not-So-Secret Menu";
            // 
            // iDoubleMeatTxt
            // 
            this.iDoubleMeatTxt.AutoSize = true;
            this.iDoubleMeatTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iDoubleMeatTxt.Location = new System.Drawing.Point(61, 361);
            this.iDoubleMeatTxt.Name = "iDoubleMeatTxt";
            this.iDoubleMeatTxt.Size = new System.Drawing.Size(120, 15);
            this.iDoubleMeatTxt.TabIndex = 15;
            this.iDoubleMeatTxt.Text = "Double Meat ($2.99)";
            // 
            // i4x4Txt
            // 
            this.i4x4Txt.AutoSize = true;
            this.i4x4Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.i4x4Txt.Location = new System.Drawing.Point(61, 386);
            this.i4x4Txt.Name = "i4x4Txt";
            this.i4x4Txt.Size = new System.Drawing.Size(76, 16);
            this.i4x4Txt.TabIndex = 16;
            this.i4x4Txt.Text = "4 x 4 ($4.99)";
            // 
            // i3x3Txt
            // 
            this.i3x3Txt.AutoSize = true;
            this.i3x3Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.i3x3Txt.Location = new System.Drawing.Point(61, 412);
            this.i3x3Txt.Name = "i3x3Txt";
            this.i3x3Txt.Size = new System.Drawing.Size(76, 16);
            this.i3x3Txt.TabIndex = 17;
            this.i3x3Txt.Text = "3 x 3 ($3.99)";
            // 
            // iAnimalTxt
            // 
            this.iAnimalTxt.AutoSize = true;
            this.iAnimalTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iAnimalTxt.Location = new System.Drawing.Point(61, 439);
            this.iAnimalTxt.Name = "iAnimalTxt";
            this.iAnimalTxt.Size = new System.Drawing.Size(116, 15);
            this.iAnimalTxt.TabIndex = 18;
            this.iAnimalTxt.Text = "Animal Style ($3.99)";
            // 
            // iDoubleMeatnumeric
            // 
            this.iDoubleMeatnumeric.Location = new System.Drawing.Point(19, 356);
            this.iDoubleMeatnumeric.Name = "iDoubleMeatnumeric";
            this.iDoubleMeatnumeric.Size = new System.Drawing.Size(36, 20);
            this.iDoubleMeatnumeric.TabIndex = 19;
            // 
            // i4x4numeric
            // 
            this.i4x4numeric.Location = new System.Drawing.Point(19, 382);
            this.i4x4numeric.Name = "i4x4numeric";
            this.i4x4numeric.Size = new System.Drawing.Size(36, 20);
            this.i4x4numeric.TabIndex = 20;
            // 
            // i3x3numeric
            // 
            this.i3x3numeric.Location = new System.Drawing.Point(19, 408);
            this.i3x3numeric.Name = "i3x3numeric";
            this.i3x3numeric.Size = new System.Drawing.Size(36, 20);
            this.i3x3numeric.TabIndex = 21;
            // 
            // iAnimalnumeric
            // 
            this.iAnimalnumeric.Location = new System.Drawing.Point(19, 434);
            this.iAnimalnumeric.Name = "iAnimalnumeric";
            this.iAnimalnumeric.Size = new System.Drawing.Size(36, 20);
            this.iAnimalnumeric.TabIndex = 22;
            // 
            // iSidesTxt
            // 
            this.iSidesTxt.AutoSize = true;
            this.iSidesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iSidesTxt.Location = new System.Drawing.Point(389, 143);
            this.iSidesTxt.Name = "iSidesTxt";
            this.iSidesTxt.Size = new System.Drawing.Size(159, 16);
            this.iSidesTxt.TabIndex = 23;
            this.iSidesTxt.Text = "Beverages And Sides";
            // 
            // isSoftDrinkTxt
            // 
            this.isSoftDrinkTxt.AutoSize = true;
            this.isSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isSoftDrinkTxt.Location = new System.Drawing.Point(433, 177);
            this.isSoftDrinkTxt.Name = "isSoftDrinkTxt";
            this.isSoftDrinkTxt.Size = new System.Drawing.Size(137, 15);
            this.isSoftDrinkTxt.TabIndex = 24;
            this.isSoftDrinkTxt.Text = "Small Soft Drink ($1.25)";
            // 
            // imSoftDrinkTxt
            // 
            this.imSoftDrinkTxt.AutoSize = true;
            this.imSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.imSoftDrinkTxt.Location = new System.Drawing.Point(433, 203);
            this.imSoftDrinkTxt.Name = "imSoftDrinkTxt";
            this.imSoftDrinkTxt.Size = new System.Drawing.Size(151, 15);
            this.imSoftDrinkTxt.TabIndex = 25;
            this.imSoftDrinkTxt.Text = "Medium Soft Drink ($1.99)";
            // 
            // ilSoftDrinkTxt
            // 
            this.ilSoftDrinkTxt.AutoSize = true;
            this.ilSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ilSoftDrinkTxt.Location = new System.Drawing.Point(433, 229);
            this.ilSoftDrinkTxt.Name = "ilSoftDrinkTxt";
            this.ilSoftDrinkTxt.Size = new System.Drawing.Size(137, 15);
            this.ilSoftDrinkTxt.TabIndex = 26;
            this.ilSoftDrinkTxt.Text = "Large Soft Drink ($2.69)";
            // 
            // iShakesTxt
            // 
            this.iShakesTxt.AutoSize = true;
            this.iShakesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iShakesTxt.Location = new System.Drawing.Point(433, 255);
            this.iShakesTxt.Name = "iShakesTxt";
            this.iShakesTxt.Size = new System.Drawing.Size(145, 15);
            this.iShakesTxt.TabIndex = 27;
            this.iShakesTxt.Text = "Strawberry Shake ($2.50)";
            // 
            // iFriesTxt
            // 
            this.iFriesTxt.AutoSize = true;
            this.iFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iFriesTxt.Location = new System.Drawing.Point(433, 281);
            this.iFriesTxt.Name = "iFriesTxt";
            this.iFriesTxt.Size = new System.Drawing.Size(117, 15);
            this.iFriesTxt.TabIndex = 28;
            this.iFriesTxt.Text = "French Fries ($2.99)";
            // 
            // iChiliCheeseTxt
            // 
            this.iChiliCheeseTxt.AutoSize = true;
            this.iChiliCheeseTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iChiliCheeseTxt.Location = new System.Drawing.Point(433, 309);
            this.iChiliCheeseTxt.Name = "iChiliCheeseTxt";
            this.iChiliCheeseTxt.Size = new System.Drawing.Size(148, 15);
            this.iChiliCheeseTxt.TabIndex = 29;
            this.iChiliCheeseTxt.Text = "Chili Cheese Fries ($2.50)";
            // 
            // isSoftDrinknumeric
            // 
            this.isSoftDrinknumeric.Location = new System.Drawing.Point(392, 172);
            this.isSoftDrinknumeric.Name = "isSoftDrinknumeric";
            this.isSoftDrinknumeric.Size = new System.Drawing.Size(35, 20);
            this.isSoftDrinknumeric.TabIndex = 30;
            // 
            // imSoftDrinknumeric
            // 
            this.imSoftDrinknumeric.Location = new System.Drawing.Point(392, 198);
            this.imSoftDrinknumeric.Name = "imSoftDrinknumeric";
            this.imSoftDrinknumeric.Size = new System.Drawing.Size(35, 20);
            this.imSoftDrinknumeric.TabIndex = 31;
            // 
            // ilSoftDrinknumeric
            // 
            this.ilSoftDrinknumeric.Location = new System.Drawing.Point(392, 224);
            this.ilSoftDrinknumeric.Name = "ilSoftDrinknumeric";
            this.ilSoftDrinknumeric.Size = new System.Drawing.Size(35, 20);
            this.ilSoftDrinknumeric.TabIndex = 32;
            // 
            // iShakenumeric
            // 
            this.iShakenumeric.Location = new System.Drawing.Point(392, 250);
            this.iShakenumeric.Name = "iShakenumeric";
            this.iShakenumeric.Size = new System.Drawing.Size(35, 20);
            this.iShakenumeric.TabIndex = 33;
            // 
            // iFriesnumeric
            // 
            this.iFriesnumeric.Location = new System.Drawing.Point(392, 276);
            this.iFriesnumeric.Name = "iFriesnumeric";
            this.iFriesnumeric.Size = new System.Drawing.Size(35, 20);
            this.iFriesnumeric.TabIndex = 34;
            // 
            // iChiliCheesenumeric
            // 
            this.iChiliCheesenumeric.Location = new System.Drawing.Point(392, 304);
            this.iChiliCheesenumeric.Name = "iChiliCheesenumeric";
            this.iChiliCheesenumeric.Size = new System.Drawing.Size(35, 20);
            this.iChiliCheesenumeric.TabIndex = 35;
            // 
            // iCalculate
            // 
            this.iCalculate.Location = new System.Drawing.Point(389, 349);
            this.iCalculate.Name = "iCalculate";
            this.iCalculate.Size = new System.Drawing.Size(75, 23);
            this.iCalculate.TabIndex = 36;
            this.iCalculate.Text = "Calculate";
            this.iCalculate.UseVisualStyleBackColor = true;
            this.iCalculate.Click += new System.EventHandler(this.iCalculate_Click);
            // 
            // iTaxTxt
            // 
            this.iTaxTxt.AutoSize = true;
            this.iTaxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iTaxTxt.Location = new System.Drawing.Point(427, 393);
            this.iTaxTxt.Name = "iTaxTxt";
            this.iTaxTxt.Size = new System.Drawing.Size(37, 16);
            this.iTaxTxt.TabIndex = 37;
            this.iTaxTxt.Text = "Tax :";
            // 
            // iTotalTxt
            // 
            this.iTotalTxt.AutoSize = true;
            this.iTotalTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iTotalTxt.Location = new System.Drawing.Point(419, 431);
            this.iTotalTxt.Name = "iTotalTxt";
            this.iTotalTxt.Size = new System.Drawing.Size(45, 16);
            this.iTotalTxt.TabIndex = 38;
            this.iTotalTxt.Text = "Total :";
            // 
            // iOrderbutton
            // 
            this.iOrderbutton.Location = new System.Drawing.Point(392, 470);
            this.iOrderbutton.Name = "iOrderbutton";
            this.iOrderbutton.Size = new System.Drawing.Size(75, 23);
            this.iOrderbutton.TabIndex = 39;
            this.iOrderbutton.Text = " Order";
            this.iOrderbutton.UseVisualStyleBackColor = true;
            this.iOrderbutton.Click += new System.EventHandler(this.iOrderbutton_Click);
            // 
            // iExitbutton
            // 
            this.iExitbutton.Location = new System.Drawing.Point(509, 470);
            this.iExitbutton.Name = "iExitbutton";
            this.iExitbutton.Size = new System.Drawing.Size(75, 23);
            this.iExitbutton.TabIndex = 40;
            this.iExitbutton.Text = "Exit";
            this.iExitbutton.UseVisualStyleBackColor = true;
            this.iExitbutton.Click += new System.EventHandler(this.iExitbutton_Click);
            // 
            // iCalculatetextBox
            // 
            this.iCalculatetextBox.Location = new System.Drawing.Point(470, 352);
            this.iCalculatetextBox.Name = "iCalculatetextBox";
            this.iCalculatetextBox.ReadOnly = true;
            this.iCalculatetextBox.Size = new System.Drawing.Size(100, 20);
            this.iCalculatetextBox.TabIndex = 41;
            // 
            // iTaxtextBox
            // 
            this.iTaxtextBox.Location = new System.Drawing.Point(470, 389);
            this.iTaxtextBox.Name = "iTaxtextBox";
            this.iTaxtextBox.ReadOnly = true;
            this.iTaxtextBox.Size = new System.Drawing.Size(100, 20);
            this.iTaxtextBox.TabIndex = 42;
            // 
            // iTotaltextBox
            // 
            this.iTotaltextBox.Location = new System.Drawing.Point(470, 430);
            this.iTotaltextBox.Name = "iTotaltextBox";
            this.iTotaltextBox.ReadOnly = true;
            this.iTotaltextBox.Size = new System.Drawing.Size(100, 20);
            this.iTotaltextBox.TabIndex = 43;
            // 
            // iCostumersAddresstextBox
            // 
            this.iCostumersAddresstextBox.Location = new System.Drawing.Point(149, 136);
            this.iCostumersAddresstextBox.Name = "iCostumersAddresstextBox";
            this.iCostumersAddresstextBox.ReadOnly = true;
            this.iCostumersAddresstextBox.Size = new System.Drawing.Size(100, 20);
            this.iCostumersAddresstextBox.TabIndex = 44;
            // 
            // iCostumersAddressTxt
            // 
            this.iCostumersAddressTxt.AutoSize = true;
            this.iCostumersAddressTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iCostumersAddressTxt.Location = new System.Drawing.Point(12, 136);
            this.iCostumersAddressTxt.Name = "iCostumersAddressTxt";
            this.iCostumersAddressTxt.Size = new System.Drawing.Size(119, 15);
            this.iCostumersAddressTxt.TabIndex = 45;
            this.iCostumersAddressTxt.Text = "Costumers Address: ";
            // 
            // In_N_Out
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(652, 505);
            this.Controls.Add(this.iCostumersAddressTxt);
            this.Controls.Add(this.iCostumersAddresstextBox);
            this.Controls.Add(this.iTotaltextBox);
            this.Controls.Add(this.iTaxtextBox);
            this.Controls.Add(this.iCalculatetextBox);
            this.Controls.Add(this.iExitbutton);
            this.Controls.Add(this.iOrderbutton);
            this.Controls.Add(this.iTotalTxt);
            this.Controls.Add(this.iTaxTxt);
            this.Controls.Add(this.iCalculate);
            this.Controls.Add(this.iChiliCheesenumeric);
            this.Controls.Add(this.iFriesnumeric);
            this.Controls.Add(this.iShakenumeric);
            this.Controls.Add(this.ilSoftDrinknumeric);
            this.Controls.Add(this.imSoftDrinknumeric);
            this.Controls.Add(this.isSoftDrinknumeric);
            this.Controls.Add(this.iChiliCheeseTxt);
            this.Controls.Add(this.iFriesTxt);
            this.Controls.Add(this.iShakesTxt);
            this.Controls.Add(this.ilSoftDrinkTxt);
            this.Controls.Add(this.imSoftDrinkTxt);
            this.Controls.Add(this.isSoftDrinkTxt);
            this.Controls.Add(this.iSidesTxt);
            this.Controls.Add(this.iAnimalnumeric);
            this.Controls.Add(this.i3x3numeric);
            this.Controls.Add(this.i4x4numeric);
            this.Controls.Add(this.iDoubleMeatnumeric);
            this.Controls.Add(this.iAnimalTxt);
            this.Controls.Add(this.i3x3Txt);
            this.Controls.Add(this.i4x4Txt);
            this.Controls.Add(this.iDoubleMeatTxt);
            this.Controls.Add(this.NotSoSecretTxt);
            this.Controls.Add(this.iHamburgernumeric);
            this.Controls.Add(this.iCheeseburgernumeric);
            this.Controls.Add(this.iDoubleDoublenumeric);
            this.Controls.Add(this.iHamburgerTxt);
            this.Controls.Add(this.iChesseburgerTxt);
            this.Controls.Add(this.iDoubleDoubleTxt);
            this.Controls.Add(this.wHamburgersTxt);
            this.Controls.Add(this.InNOutPhone);
            this.Controls.Add(this.InNOutAddress);
            this.Controls.Add(this.iCostumersPhonetextBox);
            this.Controls.Add(this.iCostumersNametextBox);
            this.Controls.Add(this.iCostumersPhone);
            this.Controls.Add(this.iCostumersName);
            this.Controls.Add(this.InNOut);
            this.Name = "In_N_Out";
            this.Text = "In_N_Out";
            ((System.ComponentModel.ISupportInitialize)(this.iDoubleDoublenumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iCheeseburgernumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iHamburgernumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iDoubleMeatnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.i4x4numeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.i3x3numeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iAnimalnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.isSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ilSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iShakenumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iFriesnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iChiliCheesenumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label InNOut;
        private System.Windows.Forms.Label iCostumersName;
        private System.Windows.Forms.Label iCostumersPhone;
        private System.Windows.Forms.TextBox iCostumersNametextBox;
        private System.Windows.Forms.TextBox iCostumersPhonetextBox;
        private System.Windows.Forms.Label InNOutAddress;
        private System.Windows.Forms.Label InNOutPhone;
        private System.Windows.Forms.Label wHamburgersTxt;
        private System.Windows.Forms.Label iDoubleDoubleTxt;
        private System.Windows.Forms.Label iChesseburgerTxt;
        private System.Windows.Forms.Label iHamburgerTxt;
        private System.Windows.Forms.NumericUpDown iDoubleDoublenumeric;
        private System.Windows.Forms.NumericUpDown iCheeseburgernumeric;
        private System.Windows.Forms.NumericUpDown iHamburgernumeric;
        private System.Windows.Forms.Label NotSoSecretTxt;
        private System.Windows.Forms.Label iDoubleMeatTxt;
        private System.Windows.Forms.Label i4x4Txt;
        private System.Windows.Forms.Label i3x3Txt;
        private System.Windows.Forms.Label iAnimalTxt;
        private System.Windows.Forms.NumericUpDown iDoubleMeatnumeric;
        private System.Windows.Forms.NumericUpDown i4x4numeric;
        private System.Windows.Forms.NumericUpDown i3x3numeric;
        private System.Windows.Forms.NumericUpDown iAnimalnumeric;
        private System.Windows.Forms.Label iSidesTxt;
        private System.Windows.Forms.Label isSoftDrinkTxt;
        private System.Windows.Forms.Label imSoftDrinkTxt;
        private System.Windows.Forms.Label ilSoftDrinkTxt;
        private System.Windows.Forms.Label iShakesTxt;
        private System.Windows.Forms.Label iFriesTxt;
        private System.Windows.Forms.Label iChiliCheeseTxt;
        private System.Windows.Forms.NumericUpDown isSoftDrinknumeric;
        private System.Windows.Forms.NumericUpDown imSoftDrinknumeric;
        private System.Windows.Forms.NumericUpDown ilSoftDrinknumeric;
        private System.Windows.Forms.NumericUpDown iShakenumeric;
        private System.Windows.Forms.NumericUpDown iFriesnumeric;
        private System.Windows.Forms.NumericUpDown iChiliCheesenumeric;
        private System.Windows.Forms.Button iCalculate;
        private System.Windows.Forms.Label iTaxTxt;
        private System.Windows.Forms.Label iTotalTxt;
        private System.Windows.Forms.Button iOrderbutton;
        private System.Windows.Forms.Button iExitbutton;
        private System.Windows.Forms.TextBox iCalculatetextBox;
        private System.Windows.Forms.TextBox iTaxtextBox;
        private System.Windows.Forms.TextBox iTotaltextBox;
        private System.Windows.Forms.TextBox iCostumersAddresstextBox;
        private System.Windows.Forms.Label iCostumersAddressTxt;
    }
}