﻿namespace Food_Program
{
    partial class Macdonals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Macdonals));
            this.label1 = new System.Windows.Forms.Label();
            this.McdonaldsAddressTxt = new System.Windows.Forms.Label();
            this.McdonaldsPhoneTxt = new System.Windows.Forms.Label();
            this.mdcBurgersTxt = new System.Windows.Forms.Label();
            this.mdcCostumersName = new System.Windows.Forms.Label();
            this.mdcCostumersPhoneTxt = new System.Windows.Forms.Label();
            this.mdcCostumersNametextBox = new System.Windows.Forms.TextBox();
            this.mdcCostumersPhonetextBox = new System.Windows.Forms.TextBox();
            this.BigMacTxt = new System.Windows.Forms.Label();
            this.BigMacnumeric = new System.Windows.Forms.NumericUpDown();
            this.QuarterPounderTxt = new System.Windows.Forms.Label();
            this.QuarterPoundernumeric = new System.Windows.Forms.NumericUpDown();
            this.BaconTxt = new System.Windows.Forms.Label();
            this.Baconnumeric = new System.Windows.Forms.NumericUpDown();
            this.DeluxeTxt = new System.Windows.Forms.Label();
            this.Deluxenumeric = new System.Windows.Forms.NumericUpDown();
            this.DoublerQuarterTxt = new System.Windows.Forms.Label();
            this.Doublenumeric = new System.Windows.Forms.NumericUpDown();
            this.ChickenCrispyTxt = new System.Windows.Forms.Label();
            this.ChickenCrispynumeric = new System.Windows.Forms.NumericUpDown();
            this.ChickenGrilledTxt = new System.Windows.Forms.Label();
            this.ChickenGrillednumeric = new System.Windows.Forms.NumericUpDown();
            this.mdcSidesTxt = new System.Windows.Forms.Label();
            this.sFriesTxt = new System.Windows.Forms.Label();
            this.mdcsFriesnumeric = new System.Windows.Forms.NumericUpDown();
            this.mFriesTxt = new System.Windows.Forms.Label();
            this.mdcmFriesnumeric = new System.Windows.Forms.NumericUpDown();
            this.mdclFriesTxt = new System.Windows.Forms.Label();
            this.mdclFriesnumeric = new System.Windows.Forms.NumericUpDown();
            this.WingsTxt = new System.Windows.Forms.Label();
            this.Wingsnumeric = new System.Windows.Forms.NumericUpDown();
            this.RanchSnackTxt = new System.Windows.Forms.Label();
            this.RanchSnacknumeric = new System.Windows.Forms.NumericUpDown();
            this.RanchSnackGTxt = new System.Windows.Forms.Label();
            this.RanchSnackGnumeric = new System.Windows.Forms.NumericUpDown();
            this.mdcDrinksTxt = new System.Windows.Forms.Label();
            this.sSoftDrinkTxt = new System.Windows.Forms.Label();
            this.mdcSSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.mSoftDrinkTxt = new System.Windows.Forms.Label();
            this.mdcMSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.lSoftDrinkTxt = new System.Windows.Forms.Label();
            this.mdcLSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.ShakeTxt = new System.Windows.Forms.Label();
            this.Shakenumeric = new System.Windows.Forms.NumericUpDown();
            this.SmoothieTxt = new System.Windows.Forms.Label();
            this.Smoothienumeric = new System.Windows.Forms.NumericUpDown();
            this.Calculatebutton = new System.Windows.Forms.Button();
            this.mdcCalculatetextBox = new System.Windows.Forms.TextBox();
            this.Orderbutton = new System.Windows.Forms.Button();
            this.mdcExitbutton = new System.Windows.Forms.Button();
            this.mdcTaxtextBox = new System.Windows.Forms.TextBox();
            this.mdcTotaltextBox = new System.Windows.Forms.TextBox();
            this.mdcTaxTxt = new System.Windows.Forms.Label();
            this.mdcTotalTxt = new System.Windows.Forms.Label();
            this.mdcCostumersAddressTxt = new System.Windows.Forms.Label();
            this.mdcCostumersAddresstextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.BigMacnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.QuarterPoundernumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Baconnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Deluxenumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Doublenumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChickenCrispynumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChickenGrillednumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcsFriesnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcmFriesnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdclFriesnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Wingsnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RanchSnacknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RanchSnackGnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcSSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcMSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcLSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Shakenumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Smoothienumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(242, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "McDonald\'s";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // McdonaldsAddressTxt
            // 
            this.McdonaldsAddressTxt.AutoSize = true;
            this.McdonaldsAddressTxt.Location = new System.Drawing.Point(175, 33);
            this.McdonaldsAddressTxt.Name = "McdonaldsAddressTxt";
            this.McdonaldsAddressTxt.Size = new System.Drawing.Size(232, 13);
            this.McdonaldsAddressTxt.TabIndex = 1;
            this.McdonaldsAddressTxt.Text = "4217 S Redwood Rd, Salt Lake City, UT 84123";
            this.McdonaldsAddressTxt.Click += new System.EventHandler(this.label2_Click);
            // 
            // McdonaldsPhoneTxt
            // 
            this.McdonaldsPhoneTxt.AutoSize = true;
            this.McdonaldsPhoneTxt.Location = new System.Drawing.Point(254, 46);
            this.McdonaldsPhoneTxt.Name = "McdonaldsPhoneTxt";
            this.McdonaldsPhoneTxt.Size = new System.Drawing.Size(79, 13);
            this.McdonaldsPhoneTxt.TabIndex = 2;
            this.McdonaldsPhoneTxt.Text = "(801) 266-9615";
            // 
            // mdcBurgersTxt
            // 
            this.mdcBurgersTxt.AutoSize = true;
            this.mdcBurgersTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcBurgersTxt.Location = new System.Drawing.Point(11, 165);
            this.mdcBurgersTxt.Name = "mdcBurgersTxt";
            this.mdcBurgersTxt.Size = new System.Drawing.Size(180, 16);
            this.mdcBurgersTxt.TabIndex = 3;
            this.mdcBurgersTxt.Text = "Burgers And Sandwiches";
            // 
            // mdcCostumersName
            // 
            this.mdcCostumersName.AutoSize = true;
            this.mdcCostumersName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcCostumersName.Location = new System.Drawing.Point(11, 63);
            this.mdcCostumersName.Name = "mdcCostumersName";
            this.mdcCostumersName.Size = new System.Drawing.Size(106, 15);
            this.mdcCostumersName.TabIndex = 4;
            this.mdcCostumersName.Text = "Costumers Name:";
            this.mdcCostumersName.Click += new System.EventHandler(this.mdcform_Click);
            // 
            // mdcCostumersPhoneTxt
            // 
            this.mdcCostumersPhoneTxt.AutoSize = true;
            this.mdcCostumersPhoneTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcCostumersPhoneTxt.Location = new System.Drawing.Point(11, 88);
            this.mdcCostumersPhoneTxt.Name = "mdcCostumersPhoneTxt";
            this.mdcCostumersPhoneTxt.Size = new System.Drawing.Size(118, 15);
            this.mdcCostumersPhoneTxt.TabIndex = 5;
            this.mdcCostumersPhoneTxt.Text = "Costumers Phone #:";
            // 
            // mdcCostumersNametextBox
            // 
            this.mdcCostumersNametextBox.Location = new System.Drawing.Point(148, 62);
            this.mdcCostumersNametextBox.Name = "mdcCostumersNametextBox";
            this.mdcCostumersNametextBox.ReadOnly = true;
            this.mdcCostumersNametextBox.Size = new System.Drawing.Size(100, 20);
            this.mdcCostumersNametextBox.TabIndex = 6;
            this.mdcCostumersNametextBox.TextChanged += new System.EventHandler(this.mdcCostumersNametextBox_TextChanged);
            // 
            // mdcCostumersPhonetextBox
            // 
            this.mdcCostumersPhonetextBox.Location = new System.Drawing.Point(148, 88);
            this.mdcCostumersPhonetextBox.Name = "mdcCostumersPhonetextBox";
            this.mdcCostumersPhonetextBox.ReadOnly = true;
            this.mdcCostumersPhonetextBox.Size = new System.Drawing.Size(100, 20);
            this.mdcCostumersPhonetextBox.TabIndex = 7;
            // 
            // BigMacTxt
            // 
            this.BigMacTxt.AutoSize = true;
            this.BigMacTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BigMacTxt.Location = new System.Drawing.Point(56, 189);
            this.BigMacTxt.Name = "BigMacTxt";
            this.BigMacTxt.Size = new System.Drawing.Size(94, 15);
            this.BigMacTxt.TabIndex = 8;
            this.BigMacTxt.Text = "Big Mac ($3.99)";
            this.BigMacTxt.Click += new System.EventHandler(this.BigMacTxt_Click);
            // 
            // BigMacnumeric
            // 
            this.BigMacnumeric.Location = new System.Drawing.Point(15, 184);
            this.BigMacnumeric.Name = "BigMacnumeric";
            this.BigMacnumeric.Size = new System.Drawing.Size(34, 20);
            this.BigMacnumeric.TabIndex = 9;
            // 
            // QuarterPounderTxt
            // 
            this.QuarterPounderTxt.AutoSize = true;
            this.QuarterPounderTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuarterPounderTxt.Location = new System.Drawing.Point(56, 215);
            this.QuarterPounderTxt.Name = "QuarterPounderTxt";
            this.QuarterPounderTxt.Size = new System.Drawing.Size(210, 15);
            this.QuarterPounderTxt.TabIndex = 10;
            this.QuarterPounderTxt.Text = "Quarter Pounder with Cheese ($4.99)";
            // 
            // QuarterPoundernumeric
            // 
            this.QuarterPoundernumeric.Location = new System.Drawing.Point(15, 210);
            this.QuarterPoundernumeric.Name = "QuarterPoundernumeric";
            this.QuarterPoundernumeric.Size = new System.Drawing.Size(34, 20);
            this.QuarterPoundernumeric.TabIndex = 11;
            // 
            // BaconTxt
            // 
            this.BaconTxt.AutoSize = true;
            this.BaconTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BaconTxt.Location = new System.Drawing.Point(56, 241);
            this.BaconTxt.Name = "BaconTxt";
            this.BaconTxt.Size = new System.Drawing.Size(247, 15);
            this.BaconTxt.TabIndex = 12;
            this.BaconTxt.Text = "Bacon and Cheese Quarter Pounder ($4.99)";
            // 
            // Baconnumeric
            // 
            this.Baconnumeric.Location = new System.Drawing.Point(15, 236);
            this.Baconnumeric.Name = "Baconnumeric";
            this.Baconnumeric.Size = new System.Drawing.Size(33, 20);
            this.Baconnumeric.TabIndex = 13;
            // 
            // DeluxeTxt
            // 
            this.DeluxeTxt.AutoSize = true;
            this.DeluxeTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeluxeTxt.Location = new System.Drawing.Point(56, 267);
            this.DeluxeTxt.Name = "DeluxeTxt";
            this.DeluxeTxt.Size = new System.Drawing.Size(182, 15);
            this.DeluxeTxt.TabIndex = 14;
            this.DeluxeTxt.Text = "Deluxe Quarter Pounder ($4.99)";
            // 
            // Deluxenumeric
            // 
            this.Deluxenumeric.Location = new System.Drawing.Point(15, 262);
            this.Deluxenumeric.Name = "Deluxenumeric";
            this.Deluxenumeric.Size = new System.Drawing.Size(33, 20);
            this.Deluxenumeric.TabIndex = 15;
            this.Deluxenumeric.ValueChanged += new System.EventHandler(this.Deluxenumeric_ValueChanged);
            // 
            // DoublerQuarterTxt
            // 
            this.DoublerQuarterTxt.AutoSize = true;
            this.DoublerQuarterTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoublerQuarterTxt.Location = new System.Drawing.Point(56, 293);
            this.DoublerQuarterTxt.Name = "DoublerQuarterTxt";
            this.DoublerQuarterTxt.Size = new System.Drawing.Size(253, 15);
            this.DoublerQuarterTxt.TabIndex = 16;
            this.DoublerQuarterTxt.Text = "Double Quarter Pounder with Cheese ($4.99)";
            // 
            // Doublenumeric
            // 
            this.Doublenumeric.Location = new System.Drawing.Point(15, 288);
            this.Doublenumeric.Name = "Doublenumeric";
            this.Doublenumeric.Size = new System.Drawing.Size(33, 20);
            this.Doublenumeric.TabIndex = 17;
            // 
            // ChickenCrispyTxt
            // 
            this.ChickenCrispyTxt.AutoSize = true;
            this.ChickenCrispyTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChickenCrispyTxt.Location = new System.Drawing.Point(54, 319);
            this.ChickenCrispyTxt.Name = "ChickenCrispyTxt";
            this.ChickenCrispyTxt.Size = new System.Drawing.Size(268, 15);
            this.ChickenCrispyTxt.TabIndex = 18;
            this.ChickenCrispyTxt.Text = "Premium Crispy Chicken Club Sandwich ($3.99)";
            // 
            // ChickenCrispynumeric
            // 
            this.ChickenCrispynumeric.Location = new System.Drawing.Point(15, 314);
            this.ChickenCrispynumeric.Name = "ChickenCrispynumeric";
            this.ChickenCrispynumeric.Size = new System.Drawing.Size(33, 20);
            this.ChickenCrispynumeric.TabIndex = 19;
            // 
            // ChickenGrilledTxt
            // 
            this.ChickenGrilledTxt.AutoSize = true;
            this.ChickenGrilledTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChickenGrilledTxt.Location = new System.Drawing.Point(56, 345);
            this.ChickenGrilledTxt.Name = "ChickenGrilledTxt";
            this.ChickenGrilledTxt.Size = new System.Drawing.Size(243, 15);
            this.ChickenGrilledTxt.TabIndex = 20;
            this.ChickenGrilledTxt.Text = "Premium Grilled Chicken Sandiwch ($3.99)";
            // 
            // ChickenGrillednumeric
            // 
            this.ChickenGrillednumeric.Location = new System.Drawing.Point(15, 340);
            this.ChickenGrillednumeric.Name = "ChickenGrillednumeric";
            this.ChickenGrillednumeric.Size = new System.Drawing.Size(33, 20);
            this.ChickenGrillednumeric.TabIndex = 21;
            // 
            // mdcSidesTxt
            // 
            this.mdcSidesTxt.AutoSize = true;
            this.mdcSidesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcSidesTxt.Location = new System.Drawing.Point(407, 165);
            this.mdcSidesTxt.Name = "mdcSidesTxt";
            this.mdcSidesTxt.Size = new System.Drawing.Size(134, 16);
            this.mdcSidesTxt.TabIndex = 22;
            this.mdcSidesTxt.Text = "Snacks And Sides";
            // 
            // sFriesTxt
            // 
            this.sFriesTxt.AutoSize = true;
            this.sFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sFriesTxt.Location = new System.Drawing.Point(419, 194);
            this.sFriesTxt.Name = "sFriesTxt";
            this.sFriesTxt.Size = new System.Drawing.Size(152, 15);
            this.sFriesTxt.TabIndex = 23;
            this.sFriesTxt.Text = "Small French Fries ($1.25)";
            // 
            // mdcsFriesnumeric
            // 
            this.mdcsFriesnumeric.Location = new System.Drawing.Point(375, 189);
            this.mdcsFriesnumeric.Name = "mdcsFriesnumeric";
            this.mdcsFriesnumeric.Size = new System.Drawing.Size(31, 20);
            this.mdcsFriesnumeric.TabIndex = 24;
            // 
            // mFriesTxt
            // 
            this.mFriesTxt.AutoSize = true;
            this.mFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mFriesTxt.Location = new System.Drawing.Point(419, 220);
            this.mFriesTxt.Name = "mFriesTxt";
            this.mFriesTxt.Size = new System.Drawing.Size(166, 15);
            this.mFriesTxt.TabIndex = 25;
            this.mFriesTxt.Text = "Medium French Fries ($1.99)";
            // 
            // mdcmFriesnumeric
            // 
            this.mdcmFriesnumeric.Location = new System.Drawing.Point(375, 215);
            this.mdcmFriesnumeric.Name = "mdcmFriesnumeric";
            this.mdcmFriesnumeric.Size = new System.Drawing.Size(32, 20);
            this.mdcmFriesnumeric.TabIndex = 26;
            // 
            // mdclFriesTxt
            // 
            this.mdclFriesTxt.AutoSize = true;
            this.mdclFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdclFriesTxt.Location = new System.Drawing.Point(419, 246);
            this.mdclFriesTxt.Name = "mdclFriesTxt";
            this.mdclFriesTxt.Size = new System.Drawing.Size(152, 15);
            this.mdclFriesTxt.TabIndex = 27;
            this.mdclFriesTxt.Text = "Large French Fries ($2.69)";
            // 
            // mdclFriesnumeric
            // 
            this.mdclFriesnumeric.Location = new System.Drawing.Point(375, 241);
            this.mdclFriesnumeric.Name = "mdclFriesnumeric";
            this.mdclFriesnumeric.Size = new System.Drawing.Size(31, 20);
            this.mdclFriesnumeric.TabIndex = 28;
            // 
            // WingsTxt
            // 
            this.WingsTxt.AutoSize = true;
            this.WingsTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WingsTxt.Location = new System.Drawing.Point(419, 272);
            this.WingsTxt.Name = "WingsTxt";
            this.WingsTxt.Size = new System.Drawing.Size(122, 15);
            this.WingsTxt.TabIndex = 29;
            this.WingsTxt.Text = "Mighty Wings ($2.25)";
            // 
            // Wingsnumeric
            // 
            this.Wingsnumeric.Location = new System.Drawing.Point(374, 267);
            this.Wingsnumeric.Name = "Wingsnumeric";
            this.Wingsnumeric.Size = new System.Drawing.Size(32, 20);
            this.Wingsnumeric.TabIndex = 30;
            this.Wingsnumeric.ValueChanged += new System.EventHandler(this.Wingsnumeric_ValueChanged);
            // 
            // RanchSnackTxt
            // 
            this.RanchSnackTxt.AutoSize = true;
            this.RanchSnackTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RanchSnackTxt.Location = new System.Drawing.Point(419, 298);
            this.RanchSnackTxt.Name = "RanchSnackTxt";
            this.RanchSnackTxt.Size = new System.Drawing.Size(190, 15);
            this.RanchSnackTxt.TabIndex = 31;
            this.RanchSnackTxt.Text = "Ranch Snack Wrap Crispy ($2.99)";
            this.RanchSnackTxt.Click += new System.EventHandler(this.RanchSnackTxt_Click);
            // 
            // RanchSnacknumeric
            // 
            this.RanchSnacknumeric.Location = new System.Drawing.Point(374, 293);
            this.RanchSnacknumeric.Name = "RanchSnacknumeric";
            this.RanchSnacknumeric.Size = new System.Drawing.Size(32, 20);
            this.RanchSnacknumeric.TabIndex = 32;
            // 
            // RanchSnackGTxt
            // 
            this.RanchSnackGTxt.AutoSize = true;
            this.RanchSnackGTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RanchSnackGTxt.Location = new System.Drawing.Point(419, 324);
            this.RanchSnackGTxt.Name = "RanchSnackGTxt";
            this.RanchSnackGTxt.Size = new System.Drawing.Size(193, 15);
            this.RanchSnackGTxt.TabIndex = 33;
            this.RanchSnackGTxt.Text = "Ranch Snack Wrap Grilled ($2.99)";
            // 
            // RanchSnackGnumeric
            // 
            this.RanchSnackGnumeric.Location = new System.Drawing.Point(374, 319);
            this.RanchSnackGnumeric.Name = "RanchSnackGnumeric";
            this.RanchSnackGnumeric.Size = new System.Drawing.Size(32, 20);
            this.RanchSnackGnumeric.TabIndex = 34;
            // 
            // mdcDrinksTxt
            // 
            this.mdcDrinksTxt.AutoSize = true;
            this.mdcDrinksTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcDrinksTxt.Location = new System.Drawing.Point(12, 376);
            this.mdcDrinksTxt.Name = "mdcDrinksTxt";
            this.mdcDrinksTxt.Size = new System.Drawing.Size(84, 16);
            this.mdcDrinksTxt.TabIndex = 35;
            this.mdcDrinksTxt.Text = "Beverages";
            // 
            // sSoftDrinkTxt
            // 
            this.sSoftDrinkTxt.AutoSize = true;
            this.sSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sSoftDrinkTxt.Location = new System.Drawing.Point(56, 403);
            this.sSoftDrinkTxt.Name = "sSoftDrinkTxt";
            this.sSoftDrinkTxt.Size = new System.Drawing.Size(137, 15);
            this.sSoftDrinkTxt.TabIndex = 36;
            this.sSoftDrinkTxt.Text = "Small Soft Drink ($1.25)";
            // 
            // mdcSSoftDrinknumeric
            // 
            this.mdcSSoftDrinknumeric.Location = new System.Drawing.Point(15, 398);
            this.mdcSSoftDrinknumeric.Name = "mdcSSoftDrinknumeric";
            this.mdcSSoftDrinknumeric.Size = new System.Drawing.Size(33, 20);
            this.mdcSSoftDrinknumeric.TabIndex = 37;
            // 
            // mSoftDrinkTxt
            // 
            this.mSoftDrinkTxt.AutoSize = true;
            this.mSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mSoftDrinkTxt.Location = new System.Drawing.Point(55, 429);
            this.mSoftDrinkTxt.Name = "mSoftDrinkTxt";
            this.mSoftDrinkTxt.Size = new System.Drawing.Size(151, 15);
            this.mSoftDrinkTxt.TabIndex = 38;
            this.mSoftDrinkTxt.Text = "Medium Soft Drink ($1.99)";
            // 
            // mdcMSoftDrinknumeric
            // 
            this.mdcMSoftDrinknumeric.Location = new System.Drawing.Point(15, 424);
            this.mdcMSoftDrinknumeric.Name = "mdcMSoftDrinknumeric";
            this.mdcMSoftDrinknumeric.Size = new System.Drawing.Size(33, 20);
            this.mdcMSoftDrinknumeric.TabIndex = 39;
            // 
            // lSoftDrinkTxt
            // 
            this.lSoftDrinkTxt.AutoSize = true;
            this.lSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lSoftDrinkTxt.Location = new System.Drawing.Point(54, 455);
            this.lSoftDrinkTxt.Name = "lSoftDrinkTxt";
            this.lSoftDrinkTxt.Size = new System.Drawing.Size(137, 15);
            this.lSoftDrinkTxt.TabIndex = 40;
            this.lSoftDrinkTxt.Text = "Large Soft Drink ($2.69)";
            // 
            // mdcLSoftDrinknumeric
            // 
            this.mdcLSoftDrinknumeric.Location = new System.Drawing.Point(15, 450);
            this.mdcLSoftDrinknumeric.Name = "mdcLSoftDrinknumeric";
            this.mdcLSoftDrinknumeric.Size = new System.Drawing.Size(33, 20);
            this.mdcLSoftDrinknumeric.TabIndex = 41;
            // 
            // ShakeTxt
            // 
            this.ShakeTxt.AutoSize = true;
            this.ShakeTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShakeTxt.Location = new System.Drawing.Point(54, 480);
            this.ShakeTxt.Name = "ShakeTxt";
            this.ShakeTxt.Size = new System.Drawing.Size(190, 15);
            this.ShakeTxt.TabIndex = 42;
            this.ShakeTxt.Text = "McCafe Strawberry Shake ($2.99)\r\n";
            // 
            // Shakenumeric
            // 
            this.Shakenumeric.Location = new System.Drawing.Point(15, 475);
            this.Shakenumeric.Name = "Shakenumeric";
            this.Shakenumeric.Size = new System.Drawing.Size(33, 20);
            this.Shakenumeric.TabIndex = 43;
            // 
            // SmoothieTxt
            // 
            this.SmoothieTxt.AutoSize = true;
            this.SmoothieTxt.Location = new System.Drawing.Point(55, 508);
            this.SmoothieTxt.Name = "SmoothieTxt";
            this.SmoothieTxt.Size = new System.Drawing.Size(163, 13);
            this.SmoothieTxt.TabIndex = 44;
            this.SmoothieTxt.Text = "McCafe Mango Smoothie ($2.99)";
            // 
            // Smoothienumeric
            // 
            this.Smoothienumeric.Location = new System.Drawing.Point(16, 501);
            this.Smoothienumeric.Name = "Smoothienumeric";
            this.Smoothienumeric.Size = new System.Drawing.Size(33, 20);
            this.Smoothienumeric.TabIndex = 45;
            // 
            // Calculatebutton
            // 
            this.Calculatebutton.Location = new System.Drawing.Point(362, 392);
            this.Calculatebutton.Name = "Calculatebutton";
            this.Calculatebutton.Size = new System.Drawing.Size(75, 23);
            this.Calculatebutton.TabIndex = 46;
            this.Calculatebutton.Text = "Calculate";
            this.Calculatebutton.UseVisualStyleBackColor = true;
            this.Calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // mdcCalculatetextBox
            // 
            this.mdcCalculatetextBox.Location = new System.Drawing.Point(461, 395);
            this.mdcCalculatetextBox.Name = "mdcCalculatetextBox";
            this.mdcCalculatetextBox.ReadOnly = true;
            this.mdcCalculatetextBox.Size = new System.Drawing.Size(100, 20);
            this.mdcCalculatetextBox.TabIndex = 47;
            this.mdcCalculatetextBox.TextChanged += new System.EventHandler(this.CalculatetextBox_TextChanged);
            // 
            // Orderbutton
            // 
            this.Orderbutton.Location = new System.Drawing.Point(433, 501);
            this.Orderbutton.Name = "Orderbutton";
            this.Orderbutton.Size = new System.Drawing.Size(75, 23);
            this.Orderbutton.TabIndex = 48;
            this.Orderbutton.Text = "Order";
            this.Orderbutton.UseVisualStyleBackColor = true;
            this.Orderbutton.Click += new System.EventHandler(this.Orderbutton_Click);
            // 
            // mdcExitbutton
            // 
            this.mdcExitbutton.Location = new System.Drawing.Point(537, 501);
            this.mdcExitbutton.Name = "mdcExitbutton";
            this.mdcExitbutton.Size = new System.Drawing.Size(75, 23);
            this.mdcExitbutton.TabIndex = 49;
            this.mdcExitbutton.Text = "Exit";
            this.mdcExitbutton.UseVisualStyleBackColor = true;
            this.mdcExitbutton.Click += new System.EventHandler(this.mdcExitbutton_Click);
            // 
            // mdcTaxtextBox
            // 
            this.mdcTaxtextBox.Location = new System.Drawing.Point(461, 434);
            this.mdcTaxtextBox.Name = "mdcTaxtextBox";
            this.mdcTaxtextBox.ReadOnly = true;
            this.mdcTaxtextBox.Size = new System.Drawing.Size(100, 20);
            this.mdcTaxtextBox.TabIndex = 50;
            this.mdcTaxtextBox.TextChanged += new System.EventHandler(this.TaxtextBox_TextChanged);
            // 
            // mdcTotaltextBox
            // 
            this.mdcTotaltextBox.Location = new System.Drawing.Point(461, 471);
            this.mdcTotaltextBox.Name = "mdcTotaltextBox";
            this.mdcTotaltextBox.ReadOnly = true;
            this.mdcTotaltextBox.Size = new System.Drawing.Size(100, 20);
            this.mdcTotaltextBox.TabIndex = 53;
            // 
            // mdcTaxTxt
            // 
            this.mdcTaxTxt.AutoSize = true;
            this.mdcTaxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcTaxTxt.Location = new System.Drawing.Point(421, 438);
            this.mdcTaxTxt.Name = "mdcTaxTxt";
            this.mdcTaxTxt.Size = new System.Drawing.Size(34, 16);
            this.mdcTaxTxt.TabIndex = 54;
            this.mdcTaxTxt.Text = "Tax:";
            // 
            // mdcTotalTxt
            // 
            this.mdcTotalTxt.AutoSize = true;
            this.mdcTotalTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcTotalTxt.Location = new System.Drawing.Point(413, 472);
            this.mdcTotalTxt.Name = "mdcTotalTxt";
            this.mdcTotalTxt.Size = new System.Drawing.Size(42, 16);
            this.mdcTotalTxt.TabIndex = 55;
            this.mdcTotalTxt.Text = "Total:";
            // 
            // mdcCostumersAddressTxt
            // 
            this.mdcCostumersAddressTxt.AutoSize = true;
            this.mdcCostumersAddressTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdcCostumersAddressTxt.Location = new System.Drawing.Point(11, 114);
            this.mdcCostumersAddressTxt.Name = "mdcCostumersAddressTxt";
            this.mdcCostumersAddressTxt.Size = new System.Drawing.Size(119, 15);
            this.mdcCostumersAddressTxt.TabIndex = 56;
            this.mdcCostumersAddressTxt.Text = "Costumers Address :";
            // 
            // mdcCostumersAddresstextBox
            // 
            this.mdcCostumersAddresstextBox.Location = new System.Drawing.Point(148, 114);
            this.mdcCostumersAddresstextBox.Name = "mdcCostumersAddresstextBox";
            this.mdcCostumersAddresstextBox.ReadOnly = true;
            this.mdcCostumersAddresstextBox.Size = new System.Drawing.Size(100, 20);
            this.mdcCostumersAddresstextBox.TabIndex = 57;
            // 
            // Macdonals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(629, 533);
            this.Controls.Add(this.mdcCostumersAddresstextBox);
            this.Controls.Add(this.mdcCostumersAddressTxt);
            this.Controls.Add(this.mdcTotalTxt);
            this.Controls.Add(this.mdcTaxTxt);
            this.Controls.Add(this.mdcTotaltextBox);
            this.Controls.Add(this.mdcTaxtextBox);
            this.Controls.Add(this.mdcExitbutton);
            this.Controls.Add(this.Orderbutton);
            this.Controls.Add(this.mdcCalculatetextBox);
            this.Controls.Add(this.Calculatebutton);
            this.Controls.Add(this.Smoothienumeric);
            this.Controls.Add(this.SmoothieTxt);
            this.Controls.Add(this.Shakenumeric);
            this.Controls.Add(this.ShakeTxt);
            this.Controls.Add(this.mdcLSoftDrinknumeric);
            this.Controls.Add(this.lSoftDrinkTxt);
            this.Controls.Add(this.mdcMSoftDrinknumeric);
            this.Controls.Add(this.mSoftDrinkTxt);
            this.Controls.Add(this.mdcSSoftDrinknumeric);
            this.Controls.Add(this.sSoftDrinkTxt);
            this.Controls.Add(this.mdcDrinksTxt);
            this.Controls.Add(this.RanchSnackGnumeric);
            this.Controls.Add(this.RanchSnackGTxt);
            this.Controls.Add(this.RanchSnacknumeric);
            this.Controls.Add(this.RanchSnackTxt);
            this.Controls.Add(this.Wingsnumeric);
            this.Controls.Add(this.WingsTxt);
            this.Controls.Add(this.mdclFriesnumeric);
            this.Controls.Add(this.mdclFriesTxt);
            this.Controls.Add(this.mdcmFriesnumeric);
            this.Controls.Add(this.mFriesTxt);
            this.Controls.Add(this.mdcsFriesnumeric);
            this.Controls.Add(this.sFriesTxt);
            this.Controls.Add(this.mdcSidesTxt);
            this.Controls.Add(this.ChickenGrillednumeric);
            this.Controls.Add(this.ChickenGrilledTxt);
            this.Controls.Add(this.ChickenCrispynumeric);
            this.Controls.Add(this.ChickenCrispyTxt);
            this.Controls.Add(this.Doublenumeric);
            this.Controls.Add(this.DoublerQuarterTxt);
            this.Controls.Add(this.Deluxenumeric);
            this.Controls.Add(this.DeluxeTxt);
            this.Controls.Add(this.Baconnumeric);
            this.Controls.Add(this.BaconTxt);
            this.Controls.Add(this.QuarterPoundernumeric);
            this.Controls.Add(this.QuarterPounderTxt);
            this.Controls.Add(this.BigMacnumeric);
            this.Controls.Add(this.BigMacTxt);
            this.Controls.Add(this.mdcCostumersPhonetextBox);
            this.Controls.Add(this.mdcCostumersNametextBox);
            this.Controls.Add(this.mdcCostumersPhoneTxt);
            this.Controls.Add(this.mdcCostumersName);
            this.Controls.Add(this.mdcBurgersTxt);
            this.Controls.Add(this.McdonaldsPhoneTxt);
            this.Controls.Add(this.McdonaldsAddressTxt);
            this.Controls.Add(this.label1);
            this.Name = "Macdonals";
            this.Text = "Mcdonalds";
            this.Load += new System.EventHandler(this.Mcdonalds_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BigMacnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.QuarterPoundernumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Baconnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Deluxenumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Doublenumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChickenCrispynumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChickenGrillednumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcsFriesnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcmFriesnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdclFriesnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Wingsnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RanchSnacknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RanchSnackGnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcSSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcMSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mdcLSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Shakenumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Smoothienumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label McdonaldsAddressTxt;
        private System.Windows.Forms.Label McdonaldsPhoneTxt;
        private System.Windows.Forms.Label mdcBurgersTxt;
        private System.Windows.Forms.Label mdcCostumersName;
        private System.Windows.Forms.Label mdcCostumersPhoneTxt;
        private System.Windows.Forms.TextBox mdcCostumersNametextBox;
        private System.Windows.Forms.TextBox mdcCostumersPhonetextBox;
        private System.Windows.Forms.Label BigMacTxt;
        private System.Windows.Forms.NumericUpDown BigMacnumeric;
        private System.Windows.Forms.Label QuarterPounderTxt;
        private System.Windows.Forms.NumericUpDown QuarterPoundernumeric;
        private System.Windows.Forms.Label BaconTxt;
        private System.Windows.Forms.NumericUpDown Baconnumeric;
        private System.Windows.Forms.Label DeluxeTxt;
        private System.Windows.Forms.NumericUpDown Deluxenumeric;
        private System.Windows.Forms.Label DoublerQuarterTxt;
        private System.Windows.Forms.NumericUpDown Doublenumeric;
        private System.Windows.Forms.Label ChickenCrispyTxt;
        private System.Windows.Forms.NumericUpDown ChickenCrispynumeric;
        private System.Windows.Forms.Label ChickenGrilledTxt;
        private System.Windows.Forms.NumericUpDown ChickenGrillednumeric;
        private System.Windows.Forms.Label mdcSidesTxt;
        private System.Windows.Forms.Label sFriesTxt;
        private System.Windows.Forms.NumericUpDown mdcsFriesnumeric;
        private System.Windows.Forms.Label mFriesTxt;
        private System.Windows.Forms.NumericUpDown mdcmFriesnumeric;
        private System.Windows.Forms.Label mdclFriesTxt;
        private System.Windows.Forms.NumericUpDown mdclFriesnumeric;
        private System.Windows.Forms.Label WingsTxt;
        private System.Windows.Forms.NumericUpDown Wingsnumeric;
        private System.Windows.Forms.Label RanchSnackTxt;
        private System.Windows.Forms.NumericUpDown RanchSnacknumeric;
        private System.Windows.Forms.Label RanchSnackGTxt;
        private System.Windows.Forms.NumericUpDown RanchSnackGnumeric;
        private System.Windows.Forms.Label mdcDrinksTxt;
        private System.Windows.Forms.Label sSoftDrinkTxt;
        private System.Windows.Forms.NumericUpDown mdcSSoftDrinknumeric;
        private System.Windows.Forms.Label mSoftDrinkTxt;
        private System.Windows.Forms.NumericUpDown mdcMSoftDrinknumeric;
        private System.Windows.Forms.Label lSoftDrinkTxt;
        private System.Windows.Forms.NumericUpDown mdcLSoftDrinknumeric;
        private System.Windows.Forms.Label ShakeTxt;
        private System.Windows.Forms.NumericUpDown Shakenumeric;
        private System.Windows.Forms.Label SmoothieTxt;
        private System.Windows.Forms.NumericUpDown Smoothienumeric;
        private System.Windows.Forms.Button Calculatebutton;
        private System.Windows.Forms.TextBox mdcCalculatetextBox;
        private System.Windows.Forms.Button Orderbutton;
        private System.Windows.Forms.Button mdcExitbutton;
        private System.Windows.Forms.TextBox mdcTaxtextBox;
        private System.Windows.Forms.TextBox mdcTotaltextBox;
        private System.Windows.Forms.Label mdcTaxTxt;
        private System.Windows.Forms.Label mdcTotalTxt;
        private System.Windows.Forms.TextBox CostumersAddresstextBox;
        private System.Windows.Forms.Label mdcCostumersAddressTxt;
        private System.Windows.Forms.TextBox mdcCostumersAddresstextBox;
    }
}