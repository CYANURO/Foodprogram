﻿namespace Food_Program
{
    partial class Wendys
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Wendys));
            this.label1 = new System.Windows.Forms.Label();
            this.WendysAddressTxt = new System.Windows.Forms.Label();
            this.WendysPhoneTxt = new System.Windows.Forms.Label();
            this.wCostumersName = new System.Windows.Forms.Label();
            this.wCostumersNametextBox = new System.Windows.Forms.TextBox();
            this.wCostumersPhoneTxt = new System.Windows.Forms.Label();
            this.wCostumersPhonetextBox = new System.Windows.Forms.TextBox();
            this.wBurgersTxt = new System.Windows.Forms.Label();
            this.BaconatorTxt = new System.Windows.Forms.Label();
            this.SonOfBaconatorTxt = new System.Windows.Forms.Label();
            this.SpicyChipotleTxt = new System.Windows.Forms.Label();
            this.JrHamburgerTxt = new System.Windows.Forms.Label();
            this.JrCheeseburgerTxt = new System.Windows.Forms.Label();
            this.AsiagoTxt = new System.Windows.Forms.Label();
            this.CripsyChickenTxt = new System.Windows.Forms.Label();
            this.Baconatornumeric = new System.Windows.Forms.NumericUpDown();
            this.SonOfBaconatornumeric = new System.Windows.Forms.NumericUpDown();
            this.wSpicynumeric = new System.Windows.Forms.NumericUpDown();
            this.JrHamburgernumeric = new System.Windows.Forms.NumericUpDown();
            this.JrCheeseburgernumeric = new System.Windows.Forms.NumericUpDown();
            this.Asiagonumeric = new System.Windows.Forms.NumericUpDown();
            this.wCrispynumeric = new System.Windows.Forms.NumericUpDown();
            this.wBeverages = new System.Windows.Forms.Label();
            this.wsSoftDrinkTxt = new System.Windows.Forms.Label();
            this.wmSoftDrinkTxt = new System.Windows.Forms.Label();
            this.wlSoftDrinkTxt = new System.Windows.Forms.Label();
            this.wStrawberryTxt = new System.Windows.Forms.Label();
            this.CoffeeTxt = new System.Windows.Forms.Label();
            this.wsSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.wmSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.wlSoftDrinknumeric = new System.Windows.Forms.NumericUpDown();
            this.wStrawberrynumeric = new System.Windows.Forms.NumericUpDown();
            this.Coffeenumeric = new System.Windows.Forms.NumericUpDown();
            this.FriesAndSidesTxt = new System.Windows.Forms.Label();
            this.SmallChiliTxt = new System.Windows.Forms.Label();
            this.LargeChiliTxt = new System.Windows.Forms.Label();
            this.wsFriesTxt = new System.Windows.Forms.Label();
            this.wmFriesTxt = new System.Windows.Forms.Label();
            this.wlFriesTxt = new System.Windows.Forms.Label();
            this.ChiliFriesTxt = new System.Windows.Forms.Label();
            this.SmallChilinumeric = new System.Windows.Forms.NumericUpDown();
            this.LargeChilinumeric = new System.Windows.Forms.NumericUpDown();
            this.wsFriesnumeric = new System.Windows.Forms.NumericUpDown();
            this.wmFriesnumeric = new System.Windows.Forms.NumericUpDown();
            this.wlFriesnumeric = new System.Windows.Forms.NumericUpDown();
            this.ChiliChesenumeric = new System.Windows.Forms.NumericUpDown();
            this.wCalculatebutton = new System.Windows.Forms.Button();
            this.wTaxTxt = new System.Windows.Forms.Label();
            this.wTotalTxt = new System.Windows.Forms.Label();
            this.wOrderbutton = new System.Windows.Forms.Button();
            this.wExitbutton = new System.Windows.Forms.Button();
            this.wCalculatetextBox = new System.Windows.Forms.TextBox();
            this.wTaxtextBox = new System.Windows.Forms.TextBox();
            this.wTotaltextBox = new System.Windows.Forms.TextBox();
            this.wCostumersAddress = new System.Windows.Forms.Label();
            this.wCostumersAddresstextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Baconatornumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SonOfBaconatornumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wSpicynumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.JrHamburgernumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.JrCheeseburgernumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Asiagonumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wCrispynumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wsSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wmSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wlSoftDrinknumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wStrawberrynumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Coffeenumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SmallChilinumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LargeChilinumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wsFriesnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wmFriesnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wlFriesnumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChiliChesenumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(273, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Wendy\'s";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // WendysAddressTxt
            // 
            this.WendysAddressTxt.AutoSize = true;
            this.WendysAddressTxt.Location = new System.Drawing.Point(212, 33);
            this.WendysAddressTxt.Name = "WendysAddressTxt";
            this.WendysAddressTxt.Size = new System.Drawing.Size(218, 13);
            this.WendysAddressTxt.TabIndex = 1;
            this.WendysAddressTxt.Text = "3149 W 3500 S, West Valley City, UT 84119";
            // 
            // WendysPhoneTxt
            // 
            this.WendysPhoneTxt.AutoSize = true;
            this.WendysPhoneTxt.Location = new System.Drawing.Point(284, 49);
            this.WendysPhoneTxt.Name = "WendysPhoneTxt";
            this.WendysPhoneTxt.Size = new System.Drawing.Size(79, 13);
            this.WendysPhoneTxt.TabIndex = 2;
            this.WendysPhoneTxt.Text = "(801) 966-0477";
            this.WendysPhoneTxt.Click += new System.EventHandler(this.label3_Click);
            // 
            // wCostumersName
            // 
            this.wCostumersName.AutoSize = true;
            this.wCostumersName.Location = new System.Drawing.Point(13, 56);
            this.wCostumersName.Name = "wCostumersName";
            this.wCostumersName.Size = new System.Drawing.Size(90, 13);
            this.wCostumersName.TabIndex = 3;
            this.wCostumersName.Text = "Costumers Name:";
            // 
            // wCostumersNametextBox
            // 
            this.wCostumersNametextBox.Location = new System.Drawing.Point(133, 49);
            this.wCostumersNametextBox.Name = "wCostumersNametextBox";
            this.wCostumersNametextBox.ReadOnly = true;
            this.wCostumersNametextBox.Size = new System.Drawing.Size(100, 20);
            this.wCostumersNametextBox.TabIndex = 4;
            // 
            // wCostumersPhoneTxt
            // 
            this.wCostumersPhoneTxt.AutoSize = true;
            this.wCostumersPhoneTxt.Location = new System.Drawing.Point(13, 82);
            this.wCostumersPhoneTxt.Name = "wCostumersPhoneTxt";
            this.wCostumersPhoneTxt.Size = new System.Drawing.Size(103, 13);
            this.wCostumersPhoneTxt.TabIndex = 5;
            this.wCostumersPhoneTxt.Text = "Costumers Phone #:";
            // 
            // wCostumersPhonetextBox
            // 
            this.wCostumersPhonetextBox.Location = new System.Drawing.Point(133, 75);
            this.wCostumersPhonetextBox.Name = "wCostumersPhonetextBox";
            this.wCostumersPhonetextBox.ReadOnly = true;
            this.wCostumersPhonetextBox.Size = new System.Drawing.Size(100, 20);
            this.wCostumersPhonetextBox.TabIndex = 6;
            // 
            // wBurgersTxt
            // 
            this.wBurgersTxt.AutoSize = true;
            this.wBurgersTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wBurgersTxt.Location = new System.Drawing.Point(12, 125);
            this.wBurgersTxt.Name = "wBurgersTxt";
            this.wBurgersTxt.Size = new System.Drawing.Size(179, 16);
            this.wBurgersTxt.TabIndex = 7;
            this.wBurgersTxt.Text = "Burgers and Sandwiches\r\n";
            this.wBurgersTxt.Click += new System.EventHandler(this.wBurgersTxt_Click);
            // 
            // BaconatorTxt
            // 
            this.BaconatorTxt.AutoSize = true;
            this.BaconatorTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BaconatorTxt.Location = new System.Drawing.Point(51, 149);
            this.BaconatorTxt.Name = "BaconatorTxt";
            this.BaconatorTxt.Size = new System.Drawing.Size(105, 15);
            this.BaconatorTxt.TabIndex = 8;
            this.BaconatorTxt.Text = "Baconator ($3.99)";
            // 
            // SonOfBaconatorTxt
            // 
            this.SonOfBaconatorTxt.AutoSize = true;
            this.SonOfBaconatorTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SonOfBaconatorTxt.Location = new System.Drawing.Point(51, 175);
            this.SonOfBaconatorTxt.Name = "SonOfBaconatorTxt";
            this.SonOfBaconatorTxt.Size = new System.Drawing.Size(143, 15);
            this.SonOfBaconatorTxt.TabIndex = 9;
            this.SonOfBaconatorTxt.Text = "Son of Baconator ($2.99)";
            // 
            // SpicyChipotleTxt
            // 
            this.SpicyChipotleTxt.AutoSize = true;
            this.SpicyChipotleTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpicyChipotleTxt.Location = new System.Drawing.Point(51, 201);
            this.SpicyChipotleTxt.Name = "SpicyChipotleTxt";
            this.SpicyChipotleTxt.Size = new System.Drawing.Size(139, 15);
            this.SpicyChipotleTxt.TabIndex = 10;
            this.SpicyChipotleTxt.Text = "Spicy Chipotle Jr ($2.99)";
            // 
            // JrHamburgerTxt
            // 
            this.JrHamburgerTxt.AutoSize = true;
            this.JrHamburgerTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JrHamburgerTxt.Location = new System.Drawing.Point(51, 227);
            this.JrHamburgerTxt.Name = "JrHamburgerTxt";
            this.JrHamburgerTxt.Size = new System.Drawing.Size(128, 15);
            this.JrHamburgerTxt.TabIndex = 11;
            this.JrHamburgerTxt.Text = "Jr. Hamburger ($2.69)";
            // 
            // JrCheeseburgerTxt
            // 
            this.JrCheeseburgerTxt.AutoSize = true;
            this.JrCheeseburgerTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JrCheeseburgerTxt.Location = new System.Drawing.Point(51, 253);
            this.JrCheeseburgerTxt.Name = "JrCheeseburgerTxt";
            this.JrCheeseburgerTxt.Size = new System.Drawing.Size(143, 15);
            this.JrCheeseburgerTxt.TabIndex = 12;
            this.JrCheeseburgerTxt.Text = "Jr. Cheeseburger ($2.69)";
            // 
            // AsiagoTxt
            // 
            this.AsiagoTxt.AutoSize = true;
            this.AsiagoTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AsiagoTxt.Location = new System.Drawing.Point(51, 279);
            this.AsiagoTxt.Name = "AsiagoTxt";
            this.AsiagoTxt.Size = new System.Drawing.Size(200, 15);
            this.AsiagoTxt.TabIndex = 13;
            this.AsiagoTxt.Text = "Asiago Ranch Chicken Club ($3.99)";
            // 
            // CripsyChickenTxt
            // 
            this.CripsyChickenTxt.AutoSize = true;
            this.CripsyChickenTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CripsyChickenTxt.Location = new System.Drawing.Point(51, 305);
            this.CripsyChickenTxt.Name = "CripsyChickenTxt";
            this.CripsyChickenTxt.Size = new System.Drawing.Size(186, 15);
            this.CripsyChickenTxt.TabIndex = 14;
            this.CripsyChickenTxt.Text = "Cripsy Chicken Sandwich ($3.99)";
            // 
            // Baconatornumeric
            // 
            this.Baconatornumeric.Location = new System.Drawing.Point(15, 144);
            this.Baconatornumeric.Name = "Baconatornumeric";
            this.Baconatornumeric.Size = new System.Drawing.Size(30, 20);
            this.Baconatornumeric.TabIndex = 15;
            // 
            // SonOfBaconatornumeric
            // 
            this.SonOfBaconatornumeric.Location = new System.Drawing.Point(15, 170);
            this.SonOfBaconatornumeric.Name = "SonOfBaconatornumeric";
            this.SonOfBaconatornumeric.Size = new System.Drawing.Size(30, 20);
            this.SonOfBaconatornumeric.TabIndex = 16;
            // 
            // wSpicynumeric
            // 
            this.wSpicynumeric.Location = new System.Drawing.Point(15, 196);
            this.wSpicynumeric.Name = "wSpicynumeric";
            this.wSpicynumeric.Size = new System.Drawing.Size(30, 20);
            this.wSpicynumeric.TabIndex = 17;
            // 
            // JrHamburgernumeric
            // 
            this.JrHamburgernumeric.Location = new System.Drawing.Point(15, 222);
            this.JrHamburgernumeric.Name = "JrHamburgernumeric";
            this.JrHamburgernumeric.Size = new System.Drawing.Size(30, 20);
            this.JrHamburgernumeric.TabIndex = 18;
            // 
            // JrCheeseburgernumeric
            // 
            this.JrCheeseburgernumeric.Location = new System.Drawing.Point(15, 248);
            this.JrCheeseburgernumeric.Name = "JrCheeseburgernumeric";
            this.JrCheeseburgernumeric.Size = new System.Drawing.Size(30, 20);
            this.JrCheeseburgernumeric.TabIndex = 19;
            // 
            // Asiagonumeric
            // 
            this.Asiagonumeric.Location = new System.Drawing.Point(15, 274);
            this.Asiagonumeric.Name = "Asiagonumeric";
            this.Asiagonumeric.Size = new System.Drawing.Size(30, 20);
            this.Asiagonumeric.TabIndex = 20;
            // 
            // wCrispynumeric
            // 
            this.wCrispynumeric.Location = new System.Drawing.Point(16, 300);
            this.wCrispynumeric.Name = "wCrispynumeric";
            this.wCrispynumeric.Size = new System.Drawing.Size(29, 20);
            this.wCrispynumeric.TabIndex = 21;
            this.wCrispynumeric.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // wBeverages
            // 
            this.wBeverages.AutoSize = true;
            this.wBeverages.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wBeverages.Location = new System.Drawing.Point(12, 334);
            this.wBeverages.Name = "wBeverages";
            this.wBeverages.Size = new System.Drawing.Size(84, 16);
            this.wBeverages.TabIndex = 22;
            this.wBeverages.Text = "Beverages";
            // 
            // wsSoftDrinkTxt
            // 
            this.wsSoftDrinkTxt.AutoSize = true;
            this.wsSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wsSoftDrinkTxt.Location = new System.Drawing.Point(54, 367);
            this.wsSoftDrinkTxt.Name = "wsSoftDrinkTxt";
            this.wsSoftDrinkTxt.Size = new System.Drawing.Size(137, 15);
            this.wsSoftDrinkTxt.TabIndex = 23;
            this.wsSoftDrinkTxt.Text = "Small Soft Drink ($1.25)";
            // 
            // wmSoftDrinkTxt
            // 
            this.wmSoftDrinkTxt.AutoSize = true;
            this.wmSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wmSoftDrinkTxt.Location = new System.Drawing.Point(54, 393);
            this.wmSoftDrinkTxt.Name = "wmSoftDrinkTxt";
            this.wmSoftDrinkTxt.Size = new System.Drawing.Size(151, 15);
            this.wmSoftDrinkTxt.TabIndex = 24;
            this.wmSoftDrinkTxt.Text = "Medium Soft Drink ($1.99)";
            // 
            // wlSoftDrinkTxt
            // 
            this.wlSoftDrinkTxt.AutoSize = true;
            this.wlSoftDrinkTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wlSoftDrinkTxt.Location = new System.Drawing.Point(53, 419);
            this.wlSoftDrinkTxt.Name = "wlSoftDrinkTxt";
            this.wlSoftDrinkTxt.Size = new System.Drawing.Size(137, 15);
            this.wlSoftDrinkTxt.TabIndex = 25;
            this.wlSoftDrinkTxt.Text = "Large Soft Drink ($2.69)";
            // 
            // wStrawberryTxt
            // 
            this.wStrawberryTxt.AutoSize = true;
            this.wStrawberryTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wStrawberryTxt.Location = new System.Drawing.Point(53, 445);
            this.wStrawberryTxt.Name = "wStrawberryTxt";
            this.wStrawberryTxt.Size = new System.Drawing.Size(170, 15);
            this.wStrawberryTxt.TabIndex = 26;
            this.wStrawberryTxt.Text = "Strawberry Lemonade ($1.99)";
            // 
            // CoffeeTxt
            // 
            this.CoffeeTxt.AutoSize = true;
            this.CoffeeTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoffeeTxt.Location = new System.Drawing.Point(53, 471);
            this.CoffeeTxt.Name = "CoffeeTxt";
            this.CoffeeTxt.Size = new System.Drawing.Size(77, 15);
            this.CoffeeTxt.TabIndex = 27;
            this.CoffeeTxt.Text = "Coffee ($.99)";
            // 
            // wsSoftDrinknumeric
            // 
            this.wsSoftDrinknumeric.Location = new System.Drawing.Point(15, 362);
            this.wsSoftDrinknumeric.Name = "wsSoftDrinknumeric";
            this.wsSoftDrinknumeric.Size = new System.Drawing.Size(33, 20);
            this.wsSoftDrinknumeric.TabIndex = 28;
            // 
            // wmSoftDrinknumeric
            // 
            this.wmSoftDrinknumeric.Location = new System.Drawing.Point(15, 388);
            this.wmSoftDrinknumeric.Name = "wmSoftDrinknumeric";
            this.wmSoftDrinknumeric.Size = new System.Drawing.Size(33, 20);
            this.wmSoftDrinknumeric.TabIndex = 29;
            // 
            // wlSoftDrinknumeric
            // 
            this.wlSoftDrinknumeric.Location = new System.Drawing.Point(15, 414);
            this.wlSoftDrinknumeric.Name = "wlSoftDrinknumeric";
            this.wlSoftDrinknumeric.Size = new System.Drawing.Size(32, 20);
            this.wlSoftDrinknumeric.TabIndex = 30;
            // 
            // wStrawberrynumeric
            // 
            this.wStrawberrynumeric.Location = new System.Drawing.Point(15, 440);
            this.wStrawberrynumeric.Name = "wStrawberrynumeric";
            this.wStrawberrynumeric.Size = new System.Drawing.Size(32, 20);
            this.wStrawberrynumeric.TabIndex = 31;
            // 
            // Coffeenumeric
            // 
            this.Coffeenumeric.Location = new System.Drawing.Point(15, 466);
            this.Coffeenumeric.Name = "Coffeenumeric";
            this.Coffeenumeric.Size = new System.Drawing.Size(32, 20);
            this.Coffeenumeric.TabIndex = 32;
            // 
            // FriesAndSidesTxt
            // 
            this.FriesAndSidesTxt.AutoSize = true;
            this.FriesAndSidesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FriesAndSidesTxt.Location = new System.Drawing.Point(400, 110);
            this.FriesAndSidesTxt.Name = "FriesAndSidesTxt";
            this.FriesAndSidesTxt.Size = new System.Drawing.Size(118, 16);
            this.FriesAndSidesTxt.TabIndex = 33;
            this.FriesAndSidesTxt.Text = "Fries And Sides";
            // 
            // SmallChiliTxt
            // 
            this.SmallChiliTxt.AutoSize = true;
            this.SmallChiliTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SmallChiliTxt.Location = new System.Drawing.Point(443, 140);
            this.SmallChiliTxt.Name = "SmallChiliTxt";
            this.SmallChiliTxt.Size = new System.Drawing.Size(108, 15);
            this.SmallChiliTxt.TabIndex = 34;
            this.SmallChiliTxt.Text = "Small Chili ($2.99)";
            this.SmallChiliTxt.Click += new System.EventHandler(this.label2_Click);
            // 
            // LargeChiliTxt
            // 
            this.LargeChiliTxt.AutoSize = true;
            this.LargeChiliTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LargeChiliTxt.Location = new System.Drawing.Point(443, 164);
            this.LargeChiliTxt.Name = "LargeChiliTxt";
            this.LargeChiliTxt.Size = new System.Drawing.Size(111, 15);
            this.LargeChiliTxt.TabIndex = 35;
            this.LargeChiliTxt.Text = "Large Chilli ($3.50)";
            // 
            // wsFriesTxt
            // 
            this.wsFriesTxt.AutoSize = true;
            this.wsFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wsFriesTxt.Location = new System.Drawing.Point(443, 189);
            this.wsFriesTxt.Name = "wsFriesTxt";
            this.wsFriesTxt.Size = new System.Drawing.Size(152, 15);
            this.wsFriesTxt.TabIndex = 36;
            this.wsFriesTxt.Text = "Small French Fries ($1.25)";
            // 
            // wmFriesTxt
            // 
            this.wmFriesTxt.AutoSize = true;
            this.wmFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wmFriesTxt.Location = new System.Drawing.Point(443, 215);
            this.wmFriesTxt.Name = "wmFriesTxt";
            this.wmFriesTxt.Size = new System.Drawing.Size(166, 15);
            this.wmFriesTxt.TabIndex = 37;
            this.wmFriesTxt.Text = "Medium French Fries ($1.99)";
            // 
            // wlFriesTxt
            // 
            this.wlFriesTxt.AutoSize = true;
            this.wlFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wlFriesTxt.Location = new System.Drawing.Point(443, 241);
            this.wlFriesTxt.Name = "wlFriesTxt";
            this.wlFriesTxt.Size = new System.Drawing.Size(152, 15);
            this.wlFriesTxt.TabIndex = 38;
            this.wlFriesTxt.Text = "Large French Fries ($2.69)";
            this.wlFriesTxt.Click += new System.EventHandler(this.wlFriesTxt_Click);
            // 
            // ChiliFriesTxt
            // 
            this.ChiliFriesTxt.AutoSize = true;
            this.ChiliFriesTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChiliFriesTxt.Location = new System.Drawing.Point(443, 267);
            this.ChiliFriesTxt.Name = "ChiliFriesTxt";
            this.ChiliFriesTxt.Size = new System.Drawing.Size(148, 15);
            this.ChiliFriesTxt.TabIndex = 39;
            this.ChiliFriesTxt.Text = "Chili Cheese Fries ($2.99)";
            // 
            // SmallChilinumeric
            // 
            this.SmallChilinumeric.Location = new System.Drawing.Point(397, 133);
            this.SmallChilinumeric.Name = "SmallChilinumeric";
            this.SmallChilinumeric.Size = new System.Drawing.Size(33, 20);
            this.SmallChilinumeric.TabIndex = 40;
            // 
            // LargeChilinumeric
            // 
            this.LargeChilinumeric.Location = new System.Drawing.Point(397, 159);
            this.LargeChilinumeric.Name = "LargeChilinumeric";
            this.LargeChilinumeric.Size = new System.Drawing.Size(33, 20);
            this.LargeChilinumeric.TabIndex = 41;
            // 
            // wsFriesnumeric
            // 
            this.wsFriesnumeric.Location = new System.Drawing.Point(397, 184);
            this.wsFriesnumeric.Name = "wsFriesnumeric";
            this.wsFriesnumeric.Size = new System.Drawing.Size(33, 20);
            this.wsFriesnumeric.TabIndex = 42;
            // 
            // wmFriesnumeric
            // 
            this.wmFriesnumeric.Location = new System.Drawing.Point(398, 210);
            this.wmFriesnumeric.Name = "wmFriesnumeric";
            this.wmFriesnumeric.Size = new System.Drawing.Size(32, 20);
            this.wmFriesnumeric.TabIndex = 43;
            // 
            // wlFriesnumeric
            // 
            this.wlFriesnumeric.Location = new System.Drawing.Point(398, 236);
            this.wlFriesnumeric.Name = "wlFriesnumeric";
            this.wlFriesnumeric.Size = new System.Drawing.Size(32, 20);
            this.wlFriesnumeric.TabIndex = 44;
            // 
            // ChiliChesenumeric
            // 
            this.ChiliChesenumeric.Location = new System.Drawing.Point(397, 262);
            this.ChiliChesenumeric.Name = "ChiliChesenumeric";
            this.ChiliChesenumeric.Size = new System.Drawing.Size(33, 20);
            this.ChiliChesenumeric.TabIndex = 45;
            // 
            // wCalculatebutton
            // 
            this.wCalculatebutton.Location = new System.Drawing.Point(385, 318);
            this.wCalculatebutton.Name = "wCalculatebutton";
            this.wCalculatebutton.Size = new System.Drawing.Size(75, 23);
            this.wCalculatebutton.TabIndex = 46;
            this.wCalculatebutton.Text = "Calculate";
            this.wCalculatebutton.UseVisualStyleBackColor = true;
            this.wCalculatebutton.Click += new System.EventHandler(this.wCalculatebutton_Click);
            // 
            // wTaxTxt
            // 
            this.wTaxTxt.AutoSize = true;
            this.wTaxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wTaxTxt.Location = new System.Drawing.Point(426, 366);
            this.wTaxTxt.Name = "wTaxTxt";
            this.wTaxTxt.Size = new System.Drawing.Size(34, 16);
            this.wTaxTxt.TabIndex = 47;
            this.wTaxTxt.Text = "Tax:";
            // 
            // wTotalTxt
            // 
            this.wTotalTxt.AutoSize = true;
            this.wTotalTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wTotalTxt.Location = new System.Drawing.Point(418, 410);
            this.wTotalTxt.Name = "wTotalTxt";
            this.wTotalTxt.Size = new System.Drawing.Size(42, 16);
            this.wTotalTxt.TabIndex = 48;
            this.wTotalTxt.Text = "Total:";
            // 
            // wOrderbutton
            // 
            this.wOrderbutton.Location = new System.Drawing.Point(403, 466);
            this.wOrderbutton.Name = "wOrderbutton";
            this.wOrderbutton.Size = new System.Drawing.Size(75, 23);
            this.wOrderbutton.TabIndex = 49;
            this.wOrderbutton.Text = "Order";
            this.wOrderbutton.UseVisualStyleBackColor = true;
            this.wOrderbutton.Click += new System.EventHandler(this.wOrderbutton_Click);
            // 
            // wExitbutton
            // 
            this.wExitbutton.Location = new System.Drawing.Point(533, 466);
            this.wExitbutton.Name = "wExitbutton";
            this.wExitbutton.Size = new System.Drawing.Size(75, 23);
            this.wExitbutton.TabIndex = 50;
            this.wExitbutton.Text = "Exit";
            this.wExitbutton.UseVisualStyleBackColor = true;
            this.wExitbutton.Click += new System.EventHandler(this.wExitbutton_Click);
            // 
            // wCalculatetextBox
            // 
            this.wCalculatetextBox.Location = new System.Drawing.Point(466, 318);
            this.wCalculatetextBox.Name = "wCalculatetextBox";
            this.wCalculatetextBox.ReadOnly = true;
            this.wCalculatetextBox.Size = new System.Drawing.Size(100, 20);
            this.wCalculatetextBox.TabIndex = 51;
            // 
            // wTaxtextBox
            // 
            this.wTaxtextBox.Location = new System.Drawing.Point(466, 362);
            this.wTaxtextBox.Name = "wTaxtextBox";
            this.wTaxtextBox.ReadOnly = true;
            this.wTaxtextBox.Size = new System.Drawing.Size(100, 20);
            this.wTaxtextBox.TabIndex = 52;
            // 
            // wTotaltextBox
            // 
            this.wTotaltextBox.Location = new System.Drawing.Point(466, 406);
            this.wTotaltextBox.Name = "wTotaltextBox";
            this.wTotaltextBox.ReadOnly = true;
            this.wTotaltextBox.Size = new System.Drawing.Size(100, 20);
            this.wTotaltextBox.TabIndex = 53;
            // 
            // wCostumersAddress
            // 
            this.wCostumersAddress.AutoSize = true;
            this.wCostumersAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wCostumersAddress.Location = new System.Drawing.Point(13, 110);
            this.wCostumersAddress.Name = "wCostumersAddress";
            this.wCostumersAddress.Size = new System.Drawing.Size(100, 13);
            this.wCostumersAddress.TabIndex = 54;
            this.wCostumersAddress.Text = "Costumers Address:";
            // 
            // wCostumersAddresstextBox
            // 
            this.wCostumersAddresstextBox.Location = new System.Drawing.Point(133, 101);
            this.wCostumersAddresstextBox.Name = "wCostumersAddresstextBox";
            this.wCostumersAddresstextBox.ReadOnly = true;
            this.wCostumersAddresstextBox.Size = new System.Drawing.Size(100, 20);
            this.wCostumersAddresstextBox.TabIndex = 55;
            // 
            // Wendys
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(644, 501);
            this.Controls.Add(this.wCostumersAddresstextBox);
            this.Controls.Add(this.wCostumersAddress);
            this.Controls.Add(this.wTotaltextBox);
            this.Controls.Add(this.wTaxtextBox);
            this.Controls.Add(this.wCalculatetextBox);
            this.Controls.Add(this.wExitbutton);
            this.Controls.Add(this.wOrderbutton);
            this.Controls.Add(this.wTotalTxt);
            this.Controls.Add(this.wTaxTxt);
            this.Controls.Add(this.wCalculatebutton);
            this.Controls.Add(this.ChiliChesenumeric);
            this.Controls.Add(this.wlFriesnumeric);
            this.Controls.Add(this.wmFriesnumeric);
            this.Controls.Add(this.wsFriesnumeric);
            this.Controls.Add(this.LargeChilinumeric);
            this.Controls.Add(this.SmallChilinumeric);
            this.Controls.Add(this.ChiliFriesTxt);
            this.Controls.Add(this.wlFriesTxt);
            this.Controls.Add(this.wmFriesTxt);
            this.Controls.Add(this.wsFriesTxt);
            this.Controls.Add(this.LargeChiliTxt);
            this.Controls.Add(this.SmallChiliTxt);
            this.Controls.Add(this.FriesAndSidesTxt);
            this.Controls.Add(this.Coffeenumeric);
            this.Controls.Add(this.wStrawberrynumeric);
            this.Controls.Add(this.wlSoftDrinknumeric);
            this.Controls.Add(this.wmSoftDrinknumeric);
            this.Controls.Add(this.wsSoftDrinknumeric);
            this.Controls.Add(this.CoffeeTxt);
            this.Controls.Add(this.wStrawberryTxt);
            this.Controls.Add(this.wlSoftDrinkTxt);
            this.Controls.Add(this.wmSoftDrinkTxt);
            this.Controls.Add(this.wsSoftDrinkTxt);
            this.Controls.Add(this.wBeverages);
            this.Controls.Add(this.wCrispynumeric);
            this.Controls.Add(this.Asiagonumeric);
            this.Controls.Add(this.JrCheeseburgernumeric);
            this.Controls.Add(this.JrHamburgernumeric);
            this.Controls.Add(this.wSpicynumeric);
            this.Controls.Add(this.SonOfBaconatornumeric);
            this.Controls.Add(this.Baconatornumeric);
            this.Controls.Add(this.CripsyChickenTxt);
            this.Controls.Add(this.AsiagoTxt);
            this.Controls.Add(this.JrCheeseburgerTxt);
            this.Controls.Add(this.JrHamburgerTxt);
            this.Controls.Add(this.SpicyChipotleTxt);
            this.Controls.Add(this.SonOfBaconatorTxt);
            this.Controls.Add(this.BaconatorTxt);
            this.Controls.Add(this.wBurgersTxt);
            this.Controls.Add(this.wCostumersPhonetextBox);
            this.Controls.Add(this.wCostumersPhoneTxt);
            this.Controls.Add(this.wCostumersNametextBox);
            this.Controls.Add(this.wCostumersName);
            this.Controls.Add(this.WendysPhoneTxt);
            this.Controls.Add(this.WendysAddressTxt);
            this.Controls.Add(this.label1);
            this.Name = "Wendys";
            this.Text = "Wendys";
            this.Load += new System.EventHandler(this.Wendys_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Baconatornumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SonOfBaconatornumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wSpicynumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.JrHamburgernumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.JrCheeseburgernumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Asiagonumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wCrispynumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wsSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wmSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wlSoftDrinknumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wStrawberrynumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Coffeenumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SmallChilinumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LargeChilinumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wsFriesnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wmFriesnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wlFriesnumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChiliChesenumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label WendysAddressTxt;
        private System.Windows.Forms.Label WendysPhoneTxt;
        private System.Windows.Forms.Label wCostumersName;
        private System.Windows.Forms.TextBox wCostumersNametextBox;
        private System.Windows.Forms.Label wCostumersPhoneTxt;
        private System.Windows.Forms.TextBox wCostumersPhonetextBox;
        private System.Windows.Forms.Label wBurgersTxt;
        private System.Windows.Forms.Label BaconatorTxt;
        private System.Windows.Forms.Label SonOfBaconatorTxt;
        private System.Windows.Forms.Label SpicyChipotleTxt;
        private System.Windows.Forms.Label JrHamburgerTxt;
        private System.Windows.Forms.Label JrCheeseburgerTxt;
        private System.Windows.Forms.Label AsiagoTxt;
        private System.Windows.Forms.Label CripsyChickenTxt;
        private System.Windows.Forms.NumericUpDown Baconatornumeric;
        private System.Windows.Forms.NumericUpDown SonOfBaconatornumeric;
        private System.Windows.Forms.NumericUpDown wSpicynumeric;
        private System.Windows.Forms.NumericUpDown JrHamburgernumeric;
        private System.Windows.Forms.NumericUpDown JrCheeseburgernumeric;
        private System.Windows.Forms.NumericUpDown Asiagonumeric;
        private System.Windows.Forms.NumericUpDown wCrispynumeric;
        private System.Windows.Forms.Label wBeverages;
        private System.Windows.Forms.Label wsSoftDrinkTxt;
        private System.Windows.Forms.Label wmSoftDrinkTxt;
        private System.Windows.Forms.Label wlSoftDrinkTxt;
        private System.Windows.Forms.Label wStrawberryTxt;
        private System.Windows.Forms.Label CoffeeTxt;
        private System.Windows.Forms.NumericUpDown wsSoftDrinknumeric;
        private System.Windows.Forms.NumericUpDown wmSoftDrinknumeric;
        private System.Windows.Forms.NumericUpDown wlSoftDrinknumeric;
        private System.Windows.Forms.NumericUpDown wStrawberrynumeric;
        private System.Windows.Forms.NumericUpDown Coffeenumeric;
        private System.Windows.Forms.Label FriesAndSidesTxt;
        private System.Windows.Forms.Label SmallChiliTxt;
        private System.Windows.Forms.Label LargeChiliTxt;
        private System.Windows.Forms.Label wsFriesTxt;
        private System.Windows.Forms.Label wmFriesTxt;
        private System.Windows.Forms.Label wlFriesTxt;
        private System.Windows.Forms.Label ChiliFriesTxt;
        private System.Windows.Forms.NumericUpDown SmallChilinumeric;
        private System.Windows.Forms.NumericUpDown LargeChilinumeric;
        private System.Windows.Forms.NumericUpDown wsFriesnumeric;
        private System.Windows.Forms.NumericUpDown wmFriesnumeric;
        private System.Windows.Forms.NumericUpDown wlFriesnumeric;
        private System.Windows.Forms.NumericUpDown ChiliChesenumeric;
        private System.Windows.Forms.Button wCalculatebutton;
        private System.Windows.Forms.Label wTaxTxt;
        private System.Windows.Forms.Label wTotalTxt;
        private System.Windows.Forms.Button wOrderbutton;
        private System.Windows.Forms.Button wExitbutton;
        private System.Windows.Forms.TextBox wCalculatetextBox;
        private System.Windows.Forms.TextBox wTaxtextBox;
        private System.Windows.Forms.TextBox wTotaltextBox;
        private System.Windows.Forms.Label wCostumersAddress;
        private System.Windows.Forms.TextBox wCostumersAddresstextBox;
    }
}