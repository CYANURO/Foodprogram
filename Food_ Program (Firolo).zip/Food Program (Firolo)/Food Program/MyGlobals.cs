﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Food_Program
{
    class MyGlobals
    {
        public static String CustomersName = "";
        public static Decimal OrderTotal = 0m;
        public static String InvoiceTotalTxt = "";
        public static String CustomersPhone = "";
        public static Decimal Delivery = 0m;
        public static String CustomersAddress = "";
        public static String OrderConfirmation = "";
        public static String OrderTax = "";
        public static String Order_Totals = "";
        public static String str_orderTotal = "";
        public static String str_delivery = "";
        public static String str_pickup = "";
    
}
}
